// Off-path adapters for upstream effects that still depend on Apple services.
// Mac build.sh globs pipeline/*.cpp, so the whole translation unit is guarded.
// Overscan and contrast-mask are now ported (overscan.cpp + imprint_raster.cpp,
// contrast_mask.cpp), so no effect stubs remain on the non-Apple path.
#ifndef __APPLE__
#include "pipeline.hpp"
#include "windows_unported.hpp"

namespace spk {
}  // namespace spk
#endif  // !__APPLE__
