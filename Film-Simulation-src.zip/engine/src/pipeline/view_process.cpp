#include "view_process.hpp"
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <stdexcept>

namespace spk::view {
namespace {
using Clock = std::chrono::steady_clock;
using gpu::Arg;
double ms(Clock::time_point t) { return std::chrono::duration<double,std::milli>(Clock::now()-t).count(); }
double number(const Json& o, const char* key, double fallback, double lo, double hi) {
    const auto& v=o.at(key);
    if(v.is_null()) return fallback;
    if(!v.is_number() || !std::isfinite(v.as_double()) || v.as_double()<lo || v.as_double()>hi)
        throw std::runtime_error(std::string("view: invalid ")+key);
    return v.as_double();
}
std::vector<std::array<double,2>> points(const Json& j) {
    if(j.is_null()) return {{0,0},{1,1}};
    const auto& a=j.at("points");
    if(!a.is_array() || a.items().size()<2 || a.items().size()>256) throw std::runtime_error("view: invalid curve points");
    std::vector<std::array<double,2>> p;
    for(const auto& q:a.items()) {
        if(!q.is_array()||q.items().size()!=2)throw std::runtime_error("view: invalid curve point");
        double x=q.items()[0].as_double(-1),y=q.items()[1].as_double(-1);
        if(!std::isfinite(x)||!std::isfinite(y)||x<0||x>1||y<0||y>1||(!p.empty()&&x<=p.back()[0]))
            throw std::runtime_error("view: curve points must increase within 0..1");
        p.push_back({x,y});
    }
    return p;
}
// Fritsch-Carlson, shared behaviour with CurveMath.swift/adjustments.ts.
double curve(const std::vector<std::array<double,2>>& p,double x) {
    size_t n=p.size(); if(x<=p.front()[0])return p.front()[1]; if(x>=p.back()[0])return p.back()[1];
    std::vector<double> d(n-1),m(n);
    for(size_t i=0;i+1<n;++i)d[i]=(p[i+1][1]-p[i][1])/std::max(p[i+1][0]-p[i][0],1e-6);
    m[0]=d[0];m[n-1]=d[n-2];
    for(size_t i=1;i+1<n;++i)m[i]=d[i-1]*d[i]<=0?0:(d[i-1]+d[i])/2;
    for(size_t i=0;i+1<n;++i)if(d[i]!=0){double a=m[i]/d[i],b=m[i+1]/d[i],s=a*a+b*b;if(s>9){double t=3/std::sqrt(s);m[i]=t*a*d[i];m[i+1]=t*b*d[i];}}
    size_t i=0;while(i<n-2&&x>p[i+1][0])++i;
    double h=std::max(p[i+1][0]-p[i][0],1e-6),t=(x-p[i][0])/h,t2=t*t,t3=t2*t;
    return std::clamp((2*t3-3*t2+1)*p[i][1]+(t3-2*t2+t)*h*m[i]+(-2*t3+3*t2)*p[i+1][1]+(t3-t2)*h*m[i+1],0.0,1.0);
}
Image allocate(gpu::Gpu* gpu,uint32_t w,uint32_t h,std::string& error) {
    Image out;out.w=w;out.h=h;out.c=3;out.buf=gpu->alloc(out.bytes(),error);return out;
}
bool resample(gpu::Gpu* gpu,Image& current,uint32_t w,uint32_t h,const float* geo,uint32_t turns,uint32_t flips,std::string& error) {
    Image next=allocate(gpu,w,h,error);if(!next.valid())return false;
    uint32_t meta[]={current.w,current.h,w,h,turns,flips};
    if(!gpu->dispatch("spk_view_geometry",{Arg::buf(current.buf),Arg::inline_bytes(geo,7),Arg::inline_bytes(meta,6),Arg::buf(next.buf)},next.pixels(),error)||!gpu->flush(error))return false;
    current=std::move(next);return true;
}
std::vector<float> floats(const Json& j,size_t n) {
    if(!j.is_array()||j.items().size()!=n)throw std::runtime_error("view: invalid output transform table");
    std::vector<float> v;v.reserve(n);for(const auto& x:j.items())v.push_back(float(x.as_double()));return v;
}
// Post-Dev local adjustments. One layer is 32 floats after a one-float count
// header; brush stamps share a single table of 64, and each layer's curve
// tables share one table of 5*256 per layer. Everything travels as ordinary
// float buffers, so the view path needs no new pixel format and no extra GPU
// pass: the grade kernel reads them where it already reads its uniforms.
// Layer layout (32 floats per layer, at 32*(index+1)):
//   [0] kind  [1] opacity  [2] inverted  [3] feather
//   [4..9]   radial centre/radii/rotation, linear start/end
//   [4][5]   brush: first stamp, stamp count
//   [10]     linear direction: 1 feathered both ends, 0 one-way
//   [12..15] exposure EV, contrast, saturation, temperature
//   [16..31] colour balance: 4 zones x {r,g,b,luminance}
// Curve tables: 5 rows of 256 per layer (rgb,luma,red,green,blue), laid out as
// curves[layer*1280 + row*256 + x].
struct MaskTable {
    std::array<float,32*7> layers{};
    std::array<float,64*3> brush{};
    std::array<float,5*256*6> curves{};
};
MaskTable mask_table(const Json& adjustments) {
    MaskTable out; out.layers[0]=0.0f;
    const Json& all=adjustments.at("masks");
    if(!all.is_array()) return out;
    uint32_t layers=0, stamps=0;
    constexpr double pi=3.14159265358979323846;
    for(const auto& m:all.items()) {
        if(layers>=6u) break;
        if(!m.at("enabled").as_bool(true)) continue;
        const std::string kind=m.at("kind").as_string();
        const uint32_t code=kind=="linear"?1u:(kind=="brush"?2u:0u);
        float* b=&out.layers[32u*(layers+1u)];
        b[0]=float(code);
        b[1]=float(number(m,"opacity",100.0,0,100)/100.0);
        b[2]=m.at("inverted").as_bool(false)?1.f:0.f;
        b[3]=float(number(m,"feather",50.0,0,100)/100.0);
        if(code==0u) {
            b[4]=float(number(m,"cx",0.5,0,1));
            b[5]=float(number(m,"cy",0.5,0,1));
            b[6]=float(number(m,"rx",0.3,1e-5,4));
            b[7]=float(number(m,"ry",0.3,1e-5,4));
            const double angle=number(m,"angle",0,-360,360)*pi/180.0;
            b[8]=float(std::cos(angle));
            b[9]=float(std::sin(angle));
        } else if(code==1u) {
            b[4]=float(number(m,"x1",0.5,0,1));
            b[5]=float(number(m,"y1",0.2,0,1));
            b[6]=float(number(m,"x2",0.5,0,1));
            b[7]=float(number(m,"y2",0.8,0,1));
            // [10] linear direction: 1 = feathered both ends, 0 = one-way.
            b[10]=m.at("bidirectional").as_bool(true)?1.f:0.f;
        } else {
            b[4]=float(stamps);
            uint32_t used=0;
            const Json& pts=m.at("points");
            if(pts.is_array())
                for(const auto& p:pts.items()) {
                    if(stamps>=64u) break;
                    out.brush[size_t(stamps)*3u+0u]=float(number(p,"x",0.5,0,1));
                    out.brush[size_t(stamps)*3u+1u]=float(number(p,"y",0.5,0,1));
                    out.brush[size_t(stamps)*3u+2u]=float(number(p,"r",0.05,1e-4,1));
                    ++stamps; ++used;
                }
            b[5]=float(used);
        }
        const Json& adj=m.at("adjust");
        b[12]=float(number(adj,"exposure",0,-4,4));
        b[13]=float(number(adj,"contrast",0,-100,100)/100.0);
        b[14]=float(number(adj,"saturation",0,-100,100)/100.0);
        b[15]=float(number(adj,"temperature",0,-100,100)/100.0);
        // Per-layer colour balance: master/shadows/midtones/highlights, each
        // hue/saturation collapsed to a 3-channel offset plus a luminance gain.
        const char* zones[]={"master","shadows","midtones","highlights"};
        const Json& cb=adj.at("colorBalance");
        for(size_t z=0;z<4;++z){
            const Json& q=cb.at(zones[z]);
            double hue=number(q,"hue",0,-360,360)*pi/180, s=number(q,"saturation",0,-1,1)*.25;
            for(size_t c=0;c<3;++c) b[16+z*4+c]=float(std::cos(hue-2*pi*c/3)*s);
            b[16+z*4+3]=float(number(q,"luminance",0,-1,1)*.25);
        }
        // Per-layer curve tables: five rows of 256, monotone-cubic evaluated.
        const char* chans[]={"rgb","luma","red","green","blue"};
        const Json& curves=adj.at("curves");
        float* ct=&out.curves[size_t(layers)*5u*256u];
        bool curve_active=false;
        for(size_t row=0;row<5;++row){
            auto p=points(curves.at(chans[row]));
            if(!(p.size()==2&&p[0]==std::array<double,2>{0,0}&&p[1]==std::array<double,2>{1,1}))curve_active=true;
            for(size_t x=0;x<256;++x) ct[row*256+x]=float(curve(p,double(x)/255));
        }
        b[11]=curve_active?1.f:0.f;
        ++layers;
    }
    out.layers[0]=float(layers);
    return out;
}
}

bool process(gpu::Gpu* gpu,const Image& print,const Request& req,const Json& transform,
             const float* cmax,uint32_t cmax_count,Result& result,std::string& error,
             const gpu::BufferRef& di_lut,uint32_t di_lut_size,Image* device_output) {
    const auto started=Clock::now();
    try {
        if(!print.valid()||print.c!=2){error="view: expected device RGBA16 print";return false;}
        if(req.output_channels!=3&&req.output_channels!=4){error="view: output_channels must be 3 or 4";return false;}
        if(device_output&&(!req.rgba16||req.output_channels!=4||req.proof_long_edge)){error="view: device output requires RGBA16";return false;}
        if(!req.adjustments.is_object()||!req.geometry.is_object()){error="view: adjustments and geometry must be objects";return false;}
        const Json& a=req.adjustments;std::array<float,36> u{};
        u[0]=a.at("enabled").as_bool(true)?1.f:0.f;
        double t=number(a,"temperature",0,-100,100)/100,g=number(a,"tint",0,-100,100)/100;
        u[1]=float(1+.18*t);u[2]=float(1-.12*g);u[3]=float(1-.18*t);
        u[4]=float(std::pow(2.,number(a,"exposure",0,-20,20)));
        const char* scalars[]={"contrast","brightness","saturation","highlights","shadows","blackPoint","whitePoint"};
        for(size_t i=0;i<7;++i)u[5+i]=float(number(a,scalars[i],0,-100,100)/100);
        u[7]+=1;u[12]=.3857f;
        u[13]=float(number(a.at("vignette"),"amount",0,-100,100)/100);
        u[14]=float(number(a.at("vignette"),"midpoint",50,0,100)/100);
        const char* zones[]={"master","shadows","midtones","highlights"};
        constexpr double pi=3.14159265358979323846;
        for(size_t z=0;z<4;++z){const Json& q=a.at("colorBalance").at(zones[z]);double hue=number(q,"hue",0,-360,360)*pi/180,s=number(q,"saturation",0,-1,1)*.25;
            for(size_t c=0;c<3;++c)u[16+z*3+c]=float(std::cos(hue-2*pi*c/3)*s);
            u[28+z]=float(number(q,"luminance",0,-1,1)*.25);
        }
        std::array<float,1280> table{};const char* channels[]={"rgb","luma","red","green","blue"};
        for(size_t row=0;row<5;++row){auto p=points(a.at("curves").at(channels[row]));
            if(p.size()!=2||p[0]!=std::array<double,2>{0,0}||p[1]!=std::array<double,2>{1,1})u[15]=1;
            for(size_t x=0;x<256;++x)table[row*256+x]=float(curve(p,double(x)/255));
        }
        // Post-Dev mask clip: u[32..35] carry the picture-area rectangle in
        // normalized canvas UVs (0 = no clip). Masks fade to zero outside it.
        if(req.mask_region_set){
            u[32]=req.mask_region[0];u[33]=req.mask_region[1];
            u[34]=req.mask_region[2];u[35]=req.mask_region[3];
        }
        const Json& geom=req.geometry;const Json& crop=geom.at("crop");
        double x=number(crop,"x",0,0,1),y=number(crop,"y",0,0,1),cw=number(crop,"width",1,1e-9,1),ch=number(crop,"height",1,1e-9,1);
        if(x+cw>1.000001||y+ch>1.000001){error="view: crop extends outside source";return false;}
        double angle=number(geom,"angle",0,-45,45)*pi/180;
        int tr=int(number(geom,"quarterTurns",0,-1000,1000));uint32_t turns=uint32_t((tr%4+4)%4),flips=(geom.at("flipH").as_bool()?1u:0u)|(geom.at("flipV").as_bool()?2u:0u);
        uint32_t w=std::max(1u,uint32_t(std::lround(cw*print.w))),h=std::max(1u,uint32_t(std::lround(ch*print.h)));
        if(turns%2)std::swap(w,h);
        bool geometry=x!=0||y!=0||cw!=1||ch!=1||angle!=0||turns!=0||flips!=0;
        // Preview fast path: when the request asks for a long edge smaller than
        // the print and there is no crop/rotation/flip, grade the *downsampled*
        // RGBA16 print instead of the full-resolution one. The grade kernel
        // works in normalized source UVs, so the result is the same at a
        // fraction of the cost. The packed print is downscaled in its own
        // RGBA16 layout (not the float3 the geometry resampler uses), which is
        // what keeps the grade's input valid. Export (long_edge=0) and any
        // geometric edit still grade at full resolution for exact output.
        uint32_t grade_w=print.w,grade_h=print.h;
        Image grade_src=print;
        bool pre_scaled=false;
        if(req.long_edge&&!geometry){
            uint32_t edge=std::max(print.w,print.h);
            if(req.long_edge<edge){
                double s=double(req.long_edge)/edge;
                grade_w=std::max(1u,uint32_t(std::lround(print.w*s)));
                grade_h=std::max(1u,uint32_t(std::lround(print.h*s)));
                Image down; down.w=grade_w; down.h=grade_h; down.c=2;
                down.buf=gpu->alloc(down.bytes(),error); if(!down.buf)return false;
                uint32_t dm[]={print.w,print.h,grade_w,grade_h};
                if(!gpu->dispatch("spk_rgba16_downscale",{Arg::buf(print.buf),Arg::inline_bytes(dm,4),Arg::buf(down.buf)},grade_w*grade_h,error)||!gpu->flush(error))return false;
                grade_src=std::move(down);
                pre_scaled=true;
                w=grade_w; h=grade_h;
            }
        }
        // All request validation precedes any GPU operation.
        Image current=allocate(gpu,grade_w,grade_h,error);if(!current.valid())return false;
        auto curves=gpu->upload(table.data(),sizeof(table),error);if(!curves)return false;
        const MaskTable mask=mask_table(a);
        auto mask_buf=gpu->upload(mask.layers.data(),sizeof(mask.layers),error);if(!mask_buf)return false;
        auto brush_buf=gpu->upload(mask.brush.data(),sizeof(mask.brush),error);if(!brush_buf)return false;
        auto mask_curves_buf=gpu->upload(mask.curves.data(),sizeof(mask.curves),error);if(!mask_curves_buf)return false;
        uint32_t gm[]={uint32_t(grade_src.pixels()),grade_w,grade_h,di_lut_size};
        std::vector<Arg> grade_args={Arg::buf(grade_src.buf),Arg::inline_bytes(u.data(),u.size()),Arg::buf(curves),Arg::inline_bytes(gm,di_lut?4:3),Arg::buf(current.buf)};
        if(di_lut)grade_args.push_back(Arg::buf(di_lut));
        grade_args.push_back(Arg::buf(mask_buf));
        grade_args.push_back(Arg::buf(brush_buf));
        grade_args.push_back(Arg::buf(mask_curves_buf));
        if(!gpu->dispatch(di_lut?"spk_view_grade_di":"spk_view_grade",grade_args,grade_src.pixels(),error)||!gpu->flush(error))return false;
        if(geometry){float p[]={float(x+cw/2),float(y+ch/2),float(cw),float(ch),float(std::cos(angle)),float(std::sin(angle)),float(print.h)/print.w};
            if(!resample(gpu,current,w,h,p,turns,flips,error))return false;}
        uint32_t edge=std::max(w,h);
        if(req.long_edge&&!pre_scaled&&req.long_edge<edge){double s=double(req.long_edge)/edge;w=std::max(1u,uint32_t(std::lround(w*s)));h=std::max(1u,uint32_t(std::lround(h*s)));
            const float p[]={.5f,.5f,1,1,1,0,float(current.h)/current.w};
            if(!resample(gpu,current,w,h,p,0,0,error))return false;}
        auto stats=gpu->alloc_zeroed(12,error);if(!stats)return false;
        uint32_t encode_mode=4;
        auto convert=[&](const Json& transform,bool compress)->bool {
        const bool identity=transform.at("source_color_space").as_string()==transform.at("target_color_space").as_string();
        encode_mode=4;
        if(!identity||(compress&&transform.at("gamut_compress").at("algorithm").as_string()=="cam16ucs")){
            Image next=allocate(gpu,w,h,error);if(!next.valid())return false;
            uint32_t dm[]={uint32_t(current.elements()),uint32_t(transform.at("source_cctf_mode").as_int())};
            if(!gpu->dispatch("spk_cctf_decode",{Arg::buf(current.buf),Arg::inline_bytes(dm,2),Arg::buf(next.buf)},current.elements(),error)||!gpu->flush(error))return false;
            current=std::move(next);next=allocate(gpu,w,h,error);if(!next.valid())return false;
            auto row=floats(transform.at("matrix"),9);std::array<float,9> transpose{};
            for(size_t r=0;r<3;++r)for(size_t c=0;c<3;++c)transpose[r*3+c]=row[c*3+r];
            uint32_t count=uint32_t(current.pixels());
            if(!gpu->dispatch("spk_matmul3",{Arg::buf(current.buf),Arg::inline_bytes(transpose.data(),9),Arg::inline_bytes(&count,1),Arg::buf(next.buf)},count,error)||!gpu->flush(error))return false;
            current=std::move(next);
            const Json& gc=transform.at("gamut_compress");
            if(compress&&gc.at("algorithm").as_string()=="cam16ucs"){
                uint32_t rows=uint32_t(gc.at("cmax_rows").as_int()),cols=uint32_t(gc.at("cmax_cols").as_int());
                if(!cmax||uint64_t(rows)*cols!=cmax_count||rows<2||cols<2){error="view: invalid C_max table";return false;}
                auto mx=floats(gc.at("m_to_xyz"),9),mr=floats(gc.at("m_to_rgb"),9),k=floats(gc.at("k"),22);
                auto cb=gpu->upload(cmax,size_t(cmax_count)*4,error);if(!cb)return false;
                uint32_t meta[]={count,rows,cols,gc.at("lightness_compression_active").as_bool()?1u:0u};
                next=allocate(gpu,w,h,error);if(!next.valid())return false;
                std::vector<Arg> args={Arg::buf(current.buf),Arg::inline_bytes(mx.data(),9),Arg::inline_bytes(mr.data(),9),Arg::buf(cb),Arg::inline_bytes(k.data(),22),Arg::inline_bytes(meta,4),Arg::buf(next.buf)};
                if(req.proof_long_edge)args.push_back(Arg::buf(stats));
                if(!gpu->dispatch(req.proof_long_edge?"spk_view_cam16":"spk_cam16ucs_compress",args,count,error)||!gpu->flush(error))return false;
                current=std::move(next);
            }
            encode_mode=uint32_t(transform.at("target_cctf_mode").as_int());
            if(encode_mode>3){error="view: unsupported target transfer function";return false;}
        }
        return true;
        };
        if(!convert(transform,req.export_intent))return false;
        result.file_width=w;result.file_height=h;
        uint32_t output_channels=req.output_channels,bits=req.rgba16?16u:8u;
        if(req.proof_long_edge){
            if(!req.export_intent||!transform.at("proof").is_object()){error="view: missing proof display transform";return false;}
            uint32_t qm[]={w*h,encode_mode,bits,0,1};
            if(!gpu->dispatch("spk_view_pack",{Arg::buf(current.buf),Arg::inline_bytes(qm,5),Arg::buf(current.buf),Arg::buf(stats)},current.pixels(),error)||!gpu->flush(error))return false;
            if(req.proof_long_edge<std::max(w,h)){
                double scale=double(req.proof_long_edge)/std::max(w,h);
                w=std::max(1u,uint32_t(std::lround(w*scale)));h=std::max(1u,uint32_t(std::lround(h*scale)));
                const float p[]={.5f,.5f,1,1,1,0,float(current.h)/current.w};
                if(!resample(gpu,current,w,h,p,0,0,error))return false;
            }
            if(!convert(transform.at("proof"),false))return false;
            uint32_t counts[3]{};
            if(!gpu->read(stats.get(),0,counts,sizeof(counts),error))return false;
            result.moved_pixels=counts[0];result.clipped_pixels=counts[1];result.outside_pixels=counts[2];
            output_channels=4;bits=8;
        }
        const size_t bytes=size_t(w)*h*output_channels*(bits/8);
        // Vulkan storage writes and buffer copies operate on complete words.
        // RGB8/RGB16 can have a partial final word; only its live bytes escape.
        const size_t padded_bytes=(bytes+3)&~size_t(3);
        auto packed=gpu->alloc(padded_bytes,error);if(!packed)return false;
        uint32_t pm[]={w*h,encode_mode,bits,output_channels,0};
        const size_t jobs=output_channels==3?padded_bytes/4:size_t(w)*h;
        if(!gpu->dispatch("spk_view_pack",{Arg::buf(current.buf),Arg::inline_bytes(pm,5),Arg::buf(packed),Arg::buf(stats)},jobs,error)||!gpu->flush(error))return false;
        result.post_ms=ms(started);
        result.width=w;result.height=h;result.source_width=print.w;result.source_height=print.h;
        if(device_output){device_output->w=w;device_output->h=h;device_output->c=2;device_output->buf=std::move(packed);return true;}
        auto read=Clock::now();result.pixels.resize(padded_bytes);
        if(!gpu->read(packed.get(),0,result.pixels.data(),padded_bytes,error))return false;
        result.pixels.resize(bytes);
        result.readback_ms=ms(read);result.width=w;result.height=h;result.source_width=print.w;result.source_height=print.h;
        return true;
    }catch(const std::exception& e){error=e.what();return false;}
}
}
