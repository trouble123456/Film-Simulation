// Explicit boundaries for effects added upstream after the first Windows port.
// Included only by Windows call sites; macOS retains its upstream behavior.
#pragma once
#include "params.hpp"

namespace spk {

// Every public effect now has a Vulkan path; nothing is rejected on Windows.
// The functions below remain so the shared call sites keep their shape.
inline const char* windows_unported_error(bool /*di*/, bool /*latitude*/, bool /*mask*/,
                                         bool /*overscan*/, bool /*date*/) {
    return nullptr;
}

inline const char* windows_unported_error(const Params& p) {
    (void)p;
    return nullptr;
}

// Validate an already schema-checked delta before it mutates the session.
// Nothing is refused; contrast-mask, overscan and date-imprint are all ported.
inline const char* windows_unported_delta_error(const Json& delta) {
    (void)delta;
    return nullptr;
}

}  // namespace spk
