// Encoded ProPhoto Layer 2, ported from Canvas/Shaders.metal. Input and
// output have the same UNORM16 boundaries as Mac's offscreen textures.
layout(local_size_x=256) in;
layout(binding=0,std430) readonly buffer Input { uint v[]; } src;
layout(binding=1,std430) readonly buffer Uniforms { float v[]; } u;
layout(binding=2,std430) readonly buffer Curves { float v[]; } curves;
layout(binding=3,std430) readonly buffer Meta { uint v[]; } m;
layout(binding=4,std430) writeonly buffer Output { float v[]; } dst;
uint index1D() { return gl_GlobalInvocationID.y*(gl_NumWorkGroups.x*gl_WorkGroupSize.x)+gl_GlobalInvocationID.x; }
#ifdef SPK_DI_VIEW
layout(binding=5,std430) readonly buffer Table { float value[]; } lut;
float sample_table(uvec3 p,uint channel) { return lut.value[((p.z*m.v[3]+p.y)*m.v[3]+p.x)*3u+channel]; }
vec3 di_view(vec3 codes) {
    uint n=m.v[3];
    precise vec3 p=codes*float(n-1u);
    uvec3 lo=uvec3(floor(p)),hi=min(lo+uvec3(1),uvec3(n-1u));
    precise vec3 f=p-vec3(lo),v;
    for(uint c=0u;c<3u;++c) {
        precise float z00=sample_table(lo,c)*(1.0-f.x)+sample_table(uvec3(hi.x,lo.y,lo.z),c)*f.x;
        precise float z01=sample_table(uvec3(lo.x,hi.y,lo.z),c)*(1.0-f.x)+sample_table(uvec3(hi.x,hi.y,lo.z),c)*f.x;
        precise float z10=sample_table(uvec3(lo.x,lo.y,hi.z),c)*(1.0-f.x)+sample_table(uvec3(hi.x,lo.y,hi.z),c)*f.x;
        precise float z11=sample_table(uvec3(lo.x,hi.y,hi.z),c)*(1.0-f.x)+sample_table(hi,c)*f.x;
        v[c]=(z00*(1.0-f.y)+z01*f.y)*(1.0-f.z)+(z10*(1.0-f.y)+z11*f.y)*f.z;
    }
    return v;
}
// Post-Dev masks follow the optional DI table, so both variants keep one
// contiguous binding range. Six layers at most; the header carries the count.
layout(binding=6,std430) readonly buffer Masks { float v[]; } masks;
layout(binding=7,std430) readonly buffer Brush { float v[]; } brush;
layout(binding=8,std430) readonly buffer MaskCurves { float v[]; } mask_curves;
#else
layout(binding=5,std430) readonly buffer Masks { float v[]; } masks;
layout(binding=6,std430) readonly buffer Brush { float v[]; } brush;
layout(binding=7,std430) readonly buffer MaskCurves { float v[]; } mask_curves;
#endif
float luma(vec3 c) { return dot(c,vec3(0.2126,0.7152,0.0722)); }
float tone(float v) { return v<=u.v[12] ? 0.5*v/u.v[12] : 0.5+0.5*(v-u.v[12])/(1.0-u.v[12]); }
float curve(float v,uint row) {
    float x=clamp(v,0.0,1.0)*255.0; uint i=uint(floor(x));
    return mix(curves.v[row*256u+i],curves.v[row*256u+min(i+1u,255u)],fract(x));
}
vec3 triple(uint i) { return vec3(u.v[i],u.v[i+1u],u.v[i+2u]); }
// ------------------------------------------------------------- Post-Dev masks
//
// One layer is 32 floats at `32 * (index + 1)`; index 0 holds the layer count.
// [0] kind   [1] opacity   [2] inverted   [3] feather
// [4..9]   geometry: radial centre/radii/rotation, linear start/end
// [4][5]   brush: first stamp, stamp count
// [10]     linear: 1 = feathered both ends, 0 = one-way (soft→hard)
// [12..15] local adjust: exposure EV, contrast, saturation, temperature
// [16..31] colour balance: 4 zones x {r,g,b,luminance}
// Per-layer curve tables live in `mask_curves` at 1280 * layer (5 rows x 256).
//
// Masks live in normalized *source* coordinates. The grade runs on the
// uncropped tier print, so this pixel's own UV is already the source UV and
// the masks stay put through a crop, a rotation or a zoom.
float mask_shape(uint b,vec2 uv) {
    float kind=masks.v[b];
    float feather=clamp(masks.v[b+3u],0.004,1.0);
    if(kind<0.5) {
        // Radial: an ellipse in the mask's own rotated frame. Feather is a
        // fraction of the radius, so 0 is a hard edge and 1 fades to nothing.
        float rx=max(masks.v[b+6u],1e-4),ry=max(masks.v[b+7u],1e-4);
        vec2 d=uv-vec2(masks.v[b+4u],masks.v[b+5u]);
        float ca=masks.v[b+8u],sa=masks.v[b+9u];
        vec2 r=vec2(d.x*ca+d.y*sa,-d.x*sa+d.y*ca);
        float dist=length(vec2(r.x/rx,r.y/ry));
        return 1.0-smoothstep(1.0-feather,1.0,dist);
    }
    if(kind<1.5) {
        // Linear: the gradient runs along start→end. Bidirectional (default)
        // feathers both ends and fades to nothing past each; one-way fades in
        // from start to a hard edge at end, so the band is infinite past end.
        vec2 a=vec2(masks.v[b+4u],masks.v[b+5u]),z=vec2(masks.v[b+6u],masks.v[b+7u]);
        vec2 dir=z-a; float len2=max(dot(dir,dir),1e-8);
        float t=dot(uv-a,dir)/len2;
        float f=max(feather*0.5,0.004);
        if(masks.v[b+10u]<0.5) {
            // One-way: soft leading edge at start, hard cut at end.
            return smoothstep(0.0,f,t)*(1.0-step(1.0,t));
        }
        return smoothstep(0.0,f,t)*(1.0-smoothstep(1.0-f,1.0,t));
    }
    // Brush: a union of stamps, each a soft disc. Bounded at 64 stamps per
    // layer by the host, so the loop is a fixed, small cost per pixel.
    // A stamp's radius is a fraction of the *long* edge, so the disc stays
    // round on a non-square frame instead of stretching with the UV square.
    float aspect=float(m.v[1])/float(m.v[2]);
    float sx=max(aspect,1.0);
    uint start=uint(masks.v[b+4u]),count=uint(masks.v[b+5u]);
    float w=0.0;
    for(uint k=0u;k<count;++k) {
        uint o=(start+k)*3u;
        vec2 d=vec2((uv.x-brush.v[o])*aspect,uv.y-brush.v[o+1u]);
        float rr=max(brush.v[o+2u],1e-4)*sx;
        w=max(w,1.0-smoothstep(rr*(1.0-feather),rr,length(d)));
    }
    return w;
}
float mask_curve(float v,uint layer,uint row) {
    float x=clamp(v,0.0,1.0)*255.0; uint i=uint(floor(x));
    uint base=layer*1280u+row*256u;
    return mix(mask_curves.v[base+i],mask_curves.v[base+min(i+1u,255u)],fract(x));
}
vec3 mask_adjust(vec3 c,uint b) {
    float ev=masks.v[b+12u],contrast=masks.v[b+13u];
    float saturation=masks.v[b+14u],temperature=masks.v[b+15u];
    if(ev!=0.0) c=pow(pow(max(c,vec3(0)),vec3(2.2))*exp2(ev),vec3(1.0/2.2));
    if(contrast!=0.0) c=(c-u.v[12])*(1.0+contrast*1.2)+u.v[12];
    if(saturation!=0.0) { float l=luma(c); c=l+(c-l)*(1.0+saturation); }
    if(temperature!=0.0) c*=vec3(1.0+temperature*0.15,1.0,1.0-temperature*0.15);
    // Per-layer colour balance, mirroring the scan-side grade: four zones
    // weighted by the tone position, each a 3-channel hue/saturation offset
    // plus a luminance gain.
    {
        float l=tone(luma(c));
        float ls=clamp(tone(l),0.0,1.0);
        float ws=(1.0-ls)*(1.0-ls),wh=ls*ls,wm=max(1.0-ws-wh,0.0);
        vec3 off=vec3(0.0); float lum=1.0;
        for(uint z=0u;z<4u;++z) {
            float wgt = z==0u?1.0 : (z==1u?ws : (z==2u?wm : wh));
            uint o=b+16u+z*4u;
            off+=vec3(masks.v[o],masks.v[o+1u],masks.v[o+2u])*wgt;
            lum+=masks.v[o+3u]*wgt;
        }
        c=(c+off)*lum;
    }
    // Per-layer curve (rgb row 0, luma row 1, then per-channel rows 2..4).
    {
        uint layer=(b/32u)-1u;
        c=clamp(c,0.0,1.0);
        float ly=luma(c),ly2=mask_curve(ly,layer,1u);
        c*=ly>1e-4?ly2/ly:1.0; c=clamp(c,0.0,1.0);
        c=vec3(mask_curve(c.r,layer,0u),mask_curve(c.g,layer,0u),mask_curve(c.b,layer,0u));
        c=vec3(mask_curve(c.r,layer,2u),mask_curve(c.g,layer,3u),mask_curve(c.b,layer,4u));
    }
    return clamp(c,0.0,1.0);
}
void main() {
    uint i=index1D(); if(i>=m.v[0]) return;
    uint rg=src.v[2u*i],ba=src.v[2u*i+1u];
    vec3 c=vec3(rg&65535u,rg>>16u,ba&65535u)/65535.0;
    vec2 uv=(vec2(i%m.v[1],i/m.v[1])+0.5)/vec2(m.v[1],m.v[2]);
#ifdef SPK_DI_VIEW
    c=di_view(c);
#endif
    if(u.v[0]!=0.0) {
        c*=triple(1u);
        if(u.v[4]!=1.0) c=pow(pow(max(c,vec3(0)),vec3(2.2))*u.v[4],vec3(1.0/2.2));
        if(u.v[5]!=0.0) c=(c-u.v[12])*(1.0+u.v[5]*1.2)+u.v[12];
        if(u.v[6]!=0.0) c=pow(max(c,vec3(0)),vec3(1.0/(1.0+u.v[6]*0.8)));
        float l=tone(luma(c));
        if(u.v[9]!=0.0) c+=u.v[9]*0.25*(1.0-l)*(1.0-l)*(1.0-c);
        if(u.v[8]!=0.0) c+=u.v[8]*0.25*l*l*(u.v[8]>0.0?1.0-c:c);
        c=(c-u.v[10])/max(1.0-u.v[10]-u.v[11],0.05);
        l=luma(c); c=l+(c-l)*u.v[7];
        float ls=clamp(tone(l),0.0,1.0),ws=(1.0-ls)*(1.0-ls),wh=ls*ls,wm=max(1.0-ws-wh,0.0);
        c+=triple(16u)+triple(19u)*ws+triple(22u)*wm+triple(25u)*wh;
        c*=1.0+u.v[28]+u.v[29]*ws+u.v[30]*wm+u.v[31]*wh;
        if(u.v[15]!=0.0) {
            c=clamp(c,0.0,1.0); float ly=luma(c),ly2=curve(ly,1u);
            c*=ly>1e-4?ly2/ly:1.0; c=clamp(c,0.0,1.0);
            c=vec3(curve(c.r,0u),curve(c.g,0u),curve(c.b,0u));
            c=vec3(curve(c.r,2u),curve(c.g,3u),curve(c.b,4u));
        }
        if(u.v[13]!=0.0) {
            float fall=smoothstep(u.v[14]*1.2,1.5,length((uv-0.5)*2.0));
            c*=1.0+u.v[13]*fall*0.9;
        }
        // Local adjustments last: the mask rides on top of the global grade,
        // exactly as a Post-Dev brush stroke does in the reference app.
        // When an overscan frame is shown, u[32..35] carry the picture area
        // (the film gate) in canvas UVs; masks fade to zero outside it so a
        // local adjustment never paints the edge, holes or edge text.
        float inside=1.0;
        if(u.v[34]>u.v[32]&&u.v[35]>u.v[33]) {
            float px=clamp((uv.x-u.v[32])/max(u.v[34]-u.v[32],1e-5),0.0,1.0);
            float py=clamp((uv.y-u.v[33])/max(u.v[35]-u.v[33],1e-5),0.0,1.0);
            inside=smoothstep(0.0,0.004,px)*smoothstep(0.0,0.004,1.0-px)
                  *smoothstep(0.0,0.004,py)*smoothstep(0.0,0.004,1.0-py);
        }
        uint layers=uint(masks.v[0]);
        for(uint k=0u;k<layers;++k) {
            uint b=32u*(k+1u);
            float w=mask_shape(b,uv);
            if(masks.v[b+2u]>0.5) w=1.0-w;
            w*=clamp(masks.v[b+1u],0.0,1.0);
            w*=inside;
            if(w<=0.0005) continue;
            // Skip a layer whose whole grade is neutral (basic adjust, colour
            // balance offsets and the per-layer curve flag all zero).
            float act=abs(masks.v[b+12u])+abs(masks.v[b+13u])+abs(masks.v[b+14u])+abs(masks.v[b+15u]);
            for(uint z=0u;z<16u;++z) act+=abs(masks.v[b+16u+z]);
            act+=abs(masks.v[b+11u]);
            if(act<1e-7) continue;
            c=mix(c,mask_adjust(c,b),w);
        }
    }
    c=floor(clamp(c,0.0,1.0)*65535.0+0.5)/65535.0;
    dst.v[3u*i]=c.r; dst.v[3u*i+1u]=c.g; dst.v[3u*i+2u]=c.b;
}
