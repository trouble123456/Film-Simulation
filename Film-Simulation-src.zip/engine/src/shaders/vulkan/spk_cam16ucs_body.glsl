
// CAM16-UCS output gamut compression, transferred from gamut.metal.
// Matrix buffers are row-major here; the baked c_max table is (nL, nh).
layout(local_size_x = 256) in;
layout(set = 0, binding = 0, std430) readonly buffer Input { float value[]; } input_data;
layout(set = 0, binding = 1, std430) readonly buffer ToXyz { float value[]; } m2x;
layout(set = 0, binding = 2, std430) readonly buffer ToRgb { float value[]; } m2r;
layout(set = 0, binding = 3, std430) readonly buffer CMax { float value[]; } cmax;
layout(set = 0, binding = 4, std430) readonly buffer Constants { float value[]; } constants;
layout(set = 0, binding = 5, std430) readonly buffer Meta { uint value[]; } meta;
layout(set = 0, binding = 6, std430) writeonly buffer Output { float value[]; } output_data;

#ifdef SPK_VIEW_STATS
layout(set = 0, binding = 7, std430) buffer Stats { uint value[]; } stats;
#endif

// vulkan_gpu.cpp folds a dispatch past maxComputeWorkGroupCount[0] (65535 on
// lavapipe and Intel) into rows of workgroups; this is the 1D index it means.
uint spk_global_index() {
    return gl_GlobalInvocationID.y * (gl_NumWorkGroups.x * gl_WorkGroupSize.x) + gl_GlobalInvocationID.x;
}

void main() {
    uint i = spk_global_index();
    if (i >= meta.value[0]) return;
    uint nL = meta.value[1], nh = meta.value[2], lc_active = meta.value[3];
    float F_L = constants.value[0], N_bb = constants.value[1];
    float N_cb = constants.value[2], n_value = constants.value[3];
    float z = constants.value[4], A_w = constants.value[5];
    float c_value = constants.value[6], N_c = constants.value[7];
    float L_grid0 = constants.value[8], L_grid1 = constants.value[9];
    float h_grid0 = constants.value[10], h_step = constants.value[11];
    float threshold = constants.value[12], limit = constants.value[13];
    float power_value = constants.value[14];
    float lc_threshold = constants.value[15], lc_limit = constants.value[16];
    float lc_power = constants.value[17], L_white = constants.value[18];
    float D0 = constants.value[19], D1 = constants.value[20], D2 = constants.value[21];
    float e_c = pow(1.64 - pow(0.29, n_value), 0.73);
    float FL4 = pow(F_L, 0.25);

    float r = input_data.value[3u * i], g = input_data.value[3u * i + 1u];
    float b_input = input_data.value[3u * i + 2u];
    float X = m2x.value[0] * r + m2x.value[1] * g + m2x.value[2] * b_input;
    float Y = m2x.value[3] * r + m2x.value[4] * g + m2x.value[5] * b_input;
    float Z = m2x.value[6] * r + m2x.value[7] * g + m2x.value[8] * b_input;
    X *= 100.0; Y *= 100.0; Z *= 100.0;
    float R = 0.401288 * X + 0.650173 * Y - 0.051461 * Z;
    float G = -0.250268 * X + 1.204414 * Y + 0.045854 * Z;
    float B = -0.002079 * X + 0.048952 * Y + 0.953127 * Z;

    float Rc = D0 * R, Gc = D1 * G, Bc = D2 * B;
    float sR = Rc >= 0.0 ? 1.0 : -1.0;
    float sG = Gc >= 0.0 ? 1.0 : -1.0;
    float sB = Bc >= 0.0 ? 1.0 : -1.0;
    float fR = pow(F_L * abs(Rc) / 100.0, 0.42);
    float fG = pow(F_L * abs(Gc) / 100.0, 0.42);
    float fB = pow(F_L * abs(Bc) / 100.0, 0.42);
    float Ra = 400.0 * sR * fR / (27.13 + fR) + 0.1;
    float Ga = 400.0 * sG * fG / (27.13 + fG) + 0.1;
    float Ba = 400.0 * sB * fB / (27.13 + fB) + 0.1;
    float a = Ra - 12.0 * Ga / 11.0 + Ba / 11.0;
    float bb = (Ra + Ga - 2.0 * Ba) / 9.0;
    float hrad = atan(bb, a);
    float e_t = 0.25 * (cos(hrad + 2.0) + 3.8);
    float A = (2.0 * Ra + Ga + Ba / 20.0 - 0.305) * N_bb;
    float Aratio = A / A_w;
    float sJ = Aratio >= 0.0 ? 1.0 : -1.0;
    float J = 100.0 * sJ * pow(abs(Aratio), c_value * z);
    float den = Ra + Ga + 21.0 * Ba / 20.0;
    float t = 0.0;
    if (den != 0.0)
        t = (50000.0 / 13.0 * N_c * N_cb * e_t * sqrt(a * a + bb * bb)) / den;
    float sq = sqrt(abs(J) / 100.0);
    float C = t > 0.0 ? pow(t, 0.9) * sq * e_c : 0.0;
    float Mp = log(1.0 + 0.0228 * C * FL4) / 0.0228;
    float Jp = 1.7 * J / (1.0 + 0.007 * J);

    if (lc_active != 0u) {
        float Ln = Jp / L_white;
        if (Ln > lc_threshold) {
            float lsc = lc_limit - lc_threshold;
            float lx = (Ln - lc_threshold) / lsc;
            float ly = lx / pow(1.0 + pow(lx, lc_power), 1.0 / lc_power);
            Ln = lc_threshold + lsc * ly;
        }
        Jp = Ln * L_white;
    }

    float Lc = clamp(Jp, L_grid0, L_grid1);
    float Li = (Lc - L_grid0) / (L_grid1 - L_grid0) * float(nL - 1u);
    int l0 = clamp(int(floor(Li)), 0, int(nL) - 2);
    float lf = Li - float(l0);
    float hue_index = (hrad - h_grid0) / h_step;
    float hue_floor = floor(hue_index);
    int nhi = int(nh);
    int h0 = ((int(hue_floor) % nhi) + nhi) % nhi;
    int h1 = (h0 + 1) % nhi;
    float hf = hue_index - hue_floor;
    float c00 = cmax.value[l0 * nhi + h0], c01 = cmax.value[l0 * nhi + h1];
    float c10 = cmax.value[(l0 + 1) * nhi + h0];
    float c11 = cmax.value[(l0 + 1) * nhi + h1];
    float Cmax = (1.0 - lf) * ((1.0 - hf) * c00 + hf * c01)
               + lf * ((1.0 - hf) * c10 + hf * c11);
    float safe_value = Cmax > 1e-9 ? Cmax : 1e-9;
    float d = Mp / safe_value;
#ifdef SPK_VIEW_STATS
    if (d > threshold) atomicAdd(stats.value[0], 1u);
    if (d > 1.0) atomicAdd(stats.value[2], 1u);
#endif
    if (d > threshold) {
        float scale = limit - threshold;
        float xk = (d - threshold) / scale;
        float yk = xk / pow(1.0 + pow(xk, power_value), 1.0 / power_value);
        d = threshold + scale * yk;
    }
    float Mp_new = d * safe_value;
    float M_new = (exp(Mp_new * 0.0228) - 1.0) / 0.0228;
    float J_new = Jp / (1.7 - 0.007 * Jp);
    float C_new = M_new / FL4;
    float sJ2 = J_new >= 0.0 ? 1.0 : -1.0;
    float A2 = A_w * sJ2 * pow(abs(J_new) / 100.0, 1.0 / (c_value * z));
    float sq2 = sqrt(abs(J_new) / 100.0);
    float t2 = (sq2 > 0.0 && C_new > 0.0)
               ? pow(C_new / (sq2 * e_c), 1.0 / 0.9) : 0.0;
    float ca = cos(hrad), sa = sin(hrad);
    float p2 = A2 / N_bb + 0.305;
    const float p3 = 21.0 / 20.0;
    float a2, b2;
    if (t2 == 0.0) { a2 = 0.0; b2 = 0.0; }
    else {
        float p1 = ((50000.0 / 13.0) * N_c * N_cb * e_t) / t2;
        if (abs(sa) >= abs(ca)) {
            float p4 = p1 / sa;
            b2 = (p2 * (2.0 + p3) * (460.0 / 1403.0)) /
                 (p4 + (2.0 + p3) * (220.0 / 1403.0) * (ca / sa)
                  - (27.0 / 1403.0) + p3 * (6300.0 / 1403.0));
            a2 = b2 * (ca / sa);
        } else {
            float p5 = p1 / ca;
            a2 = (p2 * (2.0 + p3) * (460.0 / 1403.0)) /
                 (p5 + (2.0 + p3) * (220.0 / 1403.0)
                  - ((27.0 / 1403.0) - p3 * (6300.0 / 1403.0)) * (sa / ca));
            b2 = a2 * (sa / ca);
        }
    }
    float Ra2 = (460.0 * p2 + 451.0 * a2 + 288.0 * b2) / 1403.0;
    float Ga2 = (460.0 * p2 - 891.0 * a2 - 261.0 * b2) / 1403.0;
    float Ba2 = (460.0 * p2 - 220.0 * a2 - 6300.0 * b2) / 1403.0;
    float vm = Ra2 - 0.1, sign_value = vm >= 0.0 ? 1.0 : -1.0;
    float base_value = abs(vm) < 400.0 ? (27.13 * abs(vm)) / (400.0 - abs(vm)) : 0.0;
    float Rf = (100.0 / F_L) * sign_value * pow(base_value, 1.0 / 0.42) / D0;
    vm = Ga2 - 0.1; sign_value = vm >= 0.0 ? 1.0 : -1.0;
    base_value = abs(vm) < 400.0 ? (27.13 * abs(vm)) / (400.0 - abs(vm)) : 0.0;
    float Gf = (100.0 / F_L) * sign_value * pow(base_value, 1.0 / 0.42) / D1;
    vm = Ba2 - 0.1; sign_value = vm >= 0.0 ? 1.0 : -1.0;
    base_value = abs(vm) < 400.0 ? (27.13 * abs(vm)) / (400.0 - abs(vm)) : 0.0;
    float Bf = (100.0 / F_L) * sign_value * pow(base_value, 1.0 / 0.42) / D2;
    float Xn = 1.86206786 * Rf - 1.01125463 * Gf + 0.14918677 * Bf;
    float Yn = 0.38752654 * Rf + 0.62144744 * Gf - 0.00897398 * Bf;
    float Zn = -0.01584150 * Rf - 0.03412294 * Gf + 1.04996444 * Bf;
    Xn /= 100.0; Yn /= 100.0; Zn /= 100.0;
    output_data.value[3u * i] = m2r.value[0] * Xn + m2r.value[1] * Yn + m2r.value[2] * Zn;
    output_data.value[3u * i + 1u] = m2r.value[3] * Xn + m2r.value[4] * Yn + m2r.value[5] * Zn;
    output_data.value[3u * i + 2u] = m2r.value[6] * Xn + m2r.value[7] * Yn + m2r.value[8] * Zn;
}
