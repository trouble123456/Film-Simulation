#!/usr/bin/env python3
"""Verify the overscan export memory-budget fix, safely.

Runs spektralab-host, opens a real RAW, enables overscan and exports. The
memory-budget guard in view::render should downscale a full-resolution
(long_edge=0) export of a large frame before the device heap is exhausted,
instead of crashing with VK_ERROR_OUT_OF_DEVICE_MEMORY. This test never asks
for a resolution that could take the GPU down: it first proves the chain at a
moderate edge, then proves the full-res request is transparently capped.
"""
import json, os, struct, subprocess, sys, tempfile, threading, time

HOST = sys.argv[1] if len(sys.argv) > 1 else "build/qt/engine/host/spektralab-host.exe"
RESOURCES = sys.argv[2] if len(sys.argv) > 2 else "build/qt/engine/resources"
RAW = sys.argv[3] if len(sys.argv) > 3 else "BXR03199.ARW"


class Host:
    def __init__(self, cmd, resources):
        self.p = subprocess.Popen([cmd, "--resources", resources],
                                  stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                  stderr=subprocess.PIPE)
        self.next_id = 1
        self.stderr_lines = []
        threading.Thread(target=self._drain, daemon=True).start()

    def _drain(self):
        for line in self.p.stderr:
            self.stderr_lines.append(line.decode("utf-8", "replace").rstrip())

    def call(self, method, params=None, payload=b"", timeout=600):
        rid = self.next_id
        self.next_id += 1
        head = json.dumps({"id": rid, "method": method, "params": params or {}}).encode()
        self.p.stdin.write(struct.pack("<II", len(head), len(payload)) + head + payload)
        self.p.stdin.flush()
        deadline = time.time() + timeout
        while True:
            pre = self.p.stdout.read(8)
            if len(pre) < 8:
                raise RuntimeError("host closed stdout; stderr tail:\n" + "\n".join(self.stderr_lines[-30:]))
            nhead, npay = struct.unpack("<II", pre)
            head = self.p.stdout.read(nhead)
            msg = json.loads(head)
            body = self.p.stdout.read(npay)
            if msg.get("id") == rid:
                return msg, body
            if time.time() > deadline:
                raise RuntimeError("timeout waiting for " + method)


def main():
    host = Host(HOST, RESOURCES)
    try:
        h, _ = host.call("hello")
        backend = h.get("result", {}).get("capabilities", {}).get("backend", {})
        print("device:", backend.get("gpu"), "mem:", backend.get("device_memory_bytes"))

        h, _ = host.call("open", {"path": os.path.abspath(RAW)})
        if not h.get("ok"):
            print("open failed:", h.get("error")); return 1
        sid = h["result"]["session"]
        print("session:", sid, "native:", h["result"].get("width"), "x", h["result"].get("height"))

        delta = {"overscan_active": True, "overscan_format": "135",
                 "overscan_mode": "strip", "overscan_edge_text": "KODAK PORTRA 400"}
        h, _ = host.call("set_params", {"session": sid, "delta": delta})
        if not h.get("ok"):
            print("set_params overscan failed:", h.get("error")); return 1

        h, _ = host.call("get_params", {"session": sid})
        params = h["result"]["params"]

        # 1) Moderate edge: the chain must complete and produce a file.
        out1 = os.path.join(tempfile.mkdtemp(), "overscan-mid.tif")
        export = {"session": sid, "path": out1, "format": "tiff16", "color_space": "prophoto",
                  "params": params, "adjustments": {}, "geometry": {}, "long_edge": 3000}
        print("exporting at long_edge=3000 ...", flush=True)
        h, _ = host.call("export_frame", export, timeout=600)
        if not h.get("ok"):
            print("MID EXPORT FAILED:", h.get("error")); return 1
        w1, h1 = h["result"].get("width"), h["result"].get("height")
        print("mid export OK:", w1, "x", h1, "exists", os.path.exists(out1))

        # 2) Full resolution: the budget guard should cap it, not crash.
        out2 = os.path.join(tempfile.mkdtemp(), "overscan-full.tif")
        export2 = {"session": sid, "path": out2, "format": "tiff16", "color_space": "prophoto",
                   "params": params, "adjustments": {}, "geometry": {}, "long_edge": 0}
        print("exporting at full resolution (long_edge=0, budget-capped) ...", flush=True)
        h, _ = host.call("export_frame", export2, timeout=900)
        if not h.get("ok"):
            print("FULL EXPORT FAILED:", h.get("error")); return 1
        w2, h2 = h["result"].get("width"), h["result"].get("height")
        print("full export OK:", w2, "x", h2, "exists", os.path.exists(out2))
        return 0
    finally:
        try:
            host.call("shutdown")
        except Exception:
            pass
        host.p.kill()


if __name__ == "__main__":
    sys.exit(main())
