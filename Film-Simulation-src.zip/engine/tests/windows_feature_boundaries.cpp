// Exercise Windows feature refusals through the exported DLL boundary.
#include "spektrafilm/spk_engine.h"

#include <array>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

namespace {

void require(bool condition, const std::string& message) {
    if (!condition) throw std::runtime_error(message);
}

std::string params(spk_session* session) {
    char* json = nullptr;
    require(spk_get_params(session, &json) == SPK_OK && json, "get_params failed");
    std::string result(json);
    spk_string_free(json);
    return result;
}

void render(spk_engine* engine, spk_session* session) {
    spk_result result{};
    const spk_status status = spk_render(session, "full", &result);
    const bool valid = status == SPK_OK && result.rgba16 && result.texture &&
                       result.width == 32 && result.height == 16;
    const std::string error = spk_last_error(engine);
    spk_result_free(&result);
    require(valid, "default render failed after a refused request: " + error);
}

}  // namespace

int main(int argc, char** argv) {
    if (argc != 2) { std::cerr << "usage: spk_windows_feature_boundaries resources_dir\n"; return 2; }
    try {
        std::unique_ptr<spk_engine, decltype(&spk_engine_destroy)> engine(
            spk_engine_create(argv[1], nullptr), spk_engine_destroy);
        require(bool(engine), std::string("engine creation failed: ") + spk_last_error(nullptr));
        const char* capabilities = spk_capabilities(engine.get());
        require(capabilities && std::string(capabilities).find("unsupported_features") != std::string::npos,
                "Windows capabilities must disclose unported effects");

        std::vector<float> pixels(32 * 16 * 3);
        for (size_t i = 0; i < pixels.size(); ++i) pixels[i] = 0.025f + float(i % 31) * 0.025f;
        const spk_image input{pixels.data(), 32, 16, 3};
        std::unique_ptr<spk_session, decltype(&spk_session_release)> session(
            spk_open(engine.get(), &input, nullptr, nullptr), spk_session_release);
        require(bool(session), std::string("default open failed: ") + spk_last_error(engine.get()));
        render(engine.get(), session.get());

        // contrast_mask is now fully ported to the Vulkan backend, so it must
        // be *accepted* (not refused) through the exported boundary. Setting
        // it on also flips a supported field to catch partial application.
        {
            const std::string delta =
                "{\"contrast_mask_active\":true,\"contrast_mask_highlights\":0.5,"
                "\"contrast_mask_shadows\":0.5,\"print_exposure\":1.25}";
            const spk_status status = spk_set_params(session.get(), delta.c_str(), nullptr);
            const std::string error = spk_last_error(engine.get());
            require(status == SPK_OK, "contrast_mask_active should be accepted now: " + error);
            const std::string after = params(session.get());
            require(after.find("\"contrast_mask_active\":true") != std::string::npos,
                    "contrast_mask_active did not stick");
        }
        // Re-baseline after the accepted edit: the assertions below check that
        // DI export / field analysis are non-mutating relative to this state.
        const std::string before = params(session.get());

        spk_result di{};
        char* di_json = nullptr;
        const spk_status di_status = spk_render_digital_intermediate(session.get(), &di, &di_json);
        const std::string di_error = spk_last_error(engine.get());
        const bool valid_di = di.texture && di.rgba16 && di_json &&
            std::string(di_json).find("cineon") != std::string::npos;
        spk_result_free(&di);
        spk_string_free(di_json);
        require(di_status == SPK_OK && valid_di, "Cineon DI API failed: " + di_error);
        require(params(session.get()) == before, "DI export mutated the session");
        render(engine.get(), session.get());

        // contrast_mask is ported: the field analysis must succeed and return a
        // non-empty grid for the analysed tier (the session has a cached
        // negative from the render above).
        const float* mask = nullptr;
        uint32_t width = 0, height = 0;
        const spk_status mask_status = spk_contrast_mask_field(session.get(), "full", &mask, &width, &height);
        const std::string mask_error = spk_last_error(engine.get());
        require(mask_status == SPK_OK && mask && width > 0 && height > 0,
                "contrast mask field analysis failed: " + mask_error);

        // Latitude analysis remains non-mutating after the mapping kernel is
        // ported. The dedicated latitude test covers applying the returned curve.
        char* latitude_json = nullptr;
        const spk_status latitude_status = spk_scene_latitude(session.get(), nullptr, &latitude_json);
        const std::string latitude_error = spk_last_error(engine.get());
        const bool latitude_valid = latitude_json &&
            std::string(latitude_json).find("\"medium\"") != std::string::npos &&
            std::string(latitude_json).find("\"scene\"") != std::string::npos;
        spk_string_free(latitude_json);
        require(latitude_status == SPK_OK && latitude_valid, "latitude analysis failed: " + latitude_error);
        require(params(session.get()) == before, "latitude analysis mutated the session");
        render(engine.get(), session.get());
        std::cout << "Windows feature boundaries passed (contrast mask on, Cineon DI, mask field, latitude analysis)\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << error.what() << '\n';
        return 1;
    }
}
