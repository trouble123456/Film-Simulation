// agent/main.ts
import { readFile as readFile4, copyFile } from "node:fs/promises";
import { createInterface as createInterface2 } from "node:readline";
import { constants } from "node:fs";

// agent/workspace.ts
import { readFile as readFile2, mkdtemp, rm, stat } from "node:fs/promises";
import { join as join2, resolve as resolve2 } from "node:path";
import { tmpdir } from "node:os";

// agent/io.ts
import { spawn } from "node:child_process";
import { createInterface } from "node:readline";
import { existsSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

// src/shared/geometry.ts
var CROP_FULL = { x: 0, y: 0, width: 1, height: 1 };
var RATIOS = {
  square: 1,
  r3x2: 3 / 2,
  r2x3: 2 / 3,
  r4x3: 4 / 3,
  r3x4: 3 / 4,
  r16x9: 16 / 9,
  r9x16: 9 / 16,
  r5x4: 5 / 4,
  r4x5: 4 / 5,
  r7x5: 7 / 5,
  r5x7: 5 / 7
};
var TRANSPOSE = {
  free: "free",
  square: "square",
  original: "originalPortrait",
  originalPortrait: "original",
  r3x2: "r2x3",
  r2x3: "r3x2",
  r4x3: "r3x4",
  r3x4: "r4x3",
  r16x9: "r9x16",
  r9x16: "r16x9",
  r5x4: "r4x5",
  r4x5: "r5x4",
  r7x5: "r5x7",
  r5x7: "r7x5"
};
function aspectRatio(a, sourceAspect) {
  if (a === "original") return sourceAspect;
  if (a === "originalPortrait") return 1 / Math.max(sourceAspect, Number.MIN_VALUE);
  return RATIOS[a] ?? null;
}
var GEOMETRY_DEFAULT = {
  crop: CROP_FULL,
  angle: 0,
  quarterTurns: 0,
  flipH: false,
  flipV: false,
  aspect: "free",
  intendedSize: null,
  lockedRatio: null
};
var mod4 = (n) => (Math.round(n) % 4 + 4) % 4;
var isIdentity = (g) => g.crop.x === 0 && g.crop.y === 0 && g.crop.width === 1 && g.crop.height === 1 && g.angle === 0 && mod4(g.quarterTurns) === 0 && !g.flipH && !g.flipV;
var centre = (g) => ({ x: g.crop.x + g.crop.width / 2, y: g.crop.y + g.crop.height / 2 });
function lockRatio(g, sourceAspect) {
  return g.lockedRatio ?? aspectRatio(g.aspect, sourceAspect);
}
function outputSize(g, image) {
  const w = Math.max(Math.round(g.crop.width * image.width), 1);
  const h = Math.max(Math.round(g.crop.height * image.height), 1);
  return mod4(g.quarterTurns) % 2 === 0 ? { width: w, height: h } : { width: h, height: w };
}
function corners(g, image) {
  const w = Math.max(image.width, 1);
  const h = Math.max(image.height, 1);
  const c = centre(g);
  const hw = g.crop.width / 2 * w;
  const hh = g.crop.height / 2 * h;
  const a = g.angle * Math.PI / 180;
  const ca = Math.cos(a);
  const sa = Math.sin(a);
  return [
    [-1, -1],
    [1, -1],
    [1, 1],
    [-1, 1]
  ].map(([sx, sy]) => {
    const px = sx * hw;
    const py = sy * hh;
    return { x: c.x + (px * ca - py * sa) / w, y: c.y + (px * sa + py * ca) / h };
  });
}
function fits(g, image, eps = 1e-6) {
  return corners(g, image).every((p) => p.x >= -eps && p.y >= -eps && p.x <= 1 + eps && p.y <= 1 + eps);
}
function snappedToFrame(g, eps = 1e-5) {
  if (g.angle !== 0) return g;
  const crop = { ...g.crop };
  const snap = (o, l) => {
    if (crop[o] < 0 && crop[o] > -eps) {
      crop[l] += crop[o];
      crop[o] = 0;
    }
    if (crop[o] + crop[l] > 1 && crop[o] + crop[l] < 1 + eps) crop[l] = 1 - crop[o];
  };
  snap("x", "width");
  snap("y", "height");
  return { ...g, crop };
}
function fitted(g0, image) {
  const g = { ...g0, crop: { ...g0.crop } };
  g.crop.x = clamp(g.crop.x + g.crop.width / 2, 0, 1) - g.crop.width / 2;
  g.crop.y = clamp(g.crop.y + g.crop.height / 2, 0, 1) - g.crop.height / 2;
  if (fits(g, image)) return snappedToFrame(g);
  const c = centre(g);
  let lo = 0;
  let hi = 1;
  const at = (k) => ({
    ...g,
    crop: {
      x: c.x - g.crop.width * k / 2,
      y: c.y - g.crop.height * k / 2,
      width: g.crop.width * k,
      height: g.crop.height * k
    }
  });
  for (let i = 0; i < 40; i++) {
    const mid = (lo + hi) / 2;
    if (fits(at(mid), image)) lo = mid;
    else hi = mid;
  }
  return snappedToFrame(at(lo));
}
var rememberingSize = (g) => ({
  ...g,
  intendedSize: { width: g.crop.width, height: g.crop.height }
});
function constrained(g, image, anchor = { x: 0.5, y: 0.5 }) {
  const w = Math.max(image.width, 1);
  const h = Math.max(image.height, 1);
  const ratio = lockRatio(g, w / h);
  if (ratio == null) return fitted(g, image);
  const pw = g.crop.width * w;
  const ph = g.crop.height * h;
  const area = Math.max(pw * ph, 1);
  const nw = Math.sqrt(area * ratio);
  const nh = nw / ratio;
  const x1 = g.crop.x + g.crop.width * anchor.x;
  const y1 = g.crop.y + g.crop.height * anchor.y;
  const out = {
    ...g,
    crop: { x: x1 - nw / w * anchor.x, y: y1 - nh / h * anchor.y, width: nw / w, height: nh / h }
  };
  return rememberingSize(fitted(out, image));
}
function decodeGeometry(raw) {
  const o = raw && typeof raw === "object" ? raw : {};
  const c = o.crop && typeof o.crop === "object" ? o.crop : {};
  const num3 = (v, d) => typeof v === "number" && Number.isFinite(v) ? v : d;
  const size = (v) => Array.isArray(v) && v.length === 2 && typeof v[0] === "number" && typeof v[1] === "number" ? { width: v[0], height: v[1] } : null;
  return {
    crop: { x: num3(c.x, 0), y: num3(c.y, 0), width: num3(c.width, 1), height: num3(c.height, 1) },
    angle: num3(o.angle, 0),
    quarterTurns: mod4(num3(o.quarterTurns, 0)),
    flipH: o.flipH === true,
    flipV: o.flipV === true,
    aspect: typeof o.aspect === "string" && o.aspect in TRANSPOSE ? o.aspect : "free",
    intendedSize: size(o.intendedSize),
    lockedRatio: typeof o.lockedRatio === "number" ? o.lockedRatio : null
  };
}
function encodeGeometry(g) {
  const out = {
    crop: g.crop,
    angle: g.angle,
    quarterTurns: mod4(g.quarterTurns),
    flipH: g.flipH,
    flipV: g.flipV,
    aspect: g.aspect
  };
  if (g.intendedSize) out.intendedSize = [g.intendedSize.width, g.intendedSize.height];
  if (g.lockedRatio != null) out.lockedRatio = g.lockedRatio;
  return out;
}

// src/shared/filmEdge.ts
var EDGE_FORMATS = [
  { id: "135", label: "135", long: 36, short: 24, gauge: "135" },
  { id: "135_half", label: "Half frame", long: 24, short: 18, gauge: "135" },
  { id: "120_645", label: "645", long: 56, short: 41.5, gauge: "120" },
  { id: "120_6x6", label: "6\xD76", long: 56, short: 56, gauge: "120" },
  { id: "120_6x7", label: "6\xD77", long: 69.5, short: 56, gauge: "120" },
  { id: "120_6x8", label: "6\xD78", long: 76, short: 56, gauge: "120" },
  { id: "120_6x9", label: "6\xD79", long: 84, short: 56, gauge: "120" },
  { id: "135_xpan", label: "XPan", long: 65, short: 24, gauge: "135", panoramic: true },
  { id: "120_6x12", label: "6\xD712", long: 112, short: 56, gauge: "120", panoramic: true },
  { id: "120_6x17", label: "6\xD717", long: 168, short: 56, gauge: "120", panoramic: true }
];
var edgeFormat = (id) => EDGE_FORMATS.find((f) => f.id === id);
function edgeEffective(edge, gate) {
  return gate?.overscan !== false && edge.active && !!edgeFormat(edge.format);
}
function dateCamera(d, edge, gate) {
  return edgeFormat(edgeEffective(edge, gate) ? edge.format : d.camera ?? "");
}
function datePrints(face, d, edge, gate) {
  const camera = dateCamera(d, edge, gate);
  return !!camera && !("panoramic" in camera) && (face !== "data" && camera.gauge !== "120" || edgeEffective(edge, gate));
}
function dateEffective(d, edge, gate) {
  return gate?.dateImprint !== false && d.active && datePrints(d.face, d, edge, gate) && (d.face === "data" || d.placement === "frame" || edgeEffective(edge, gate));
}
function sourceGeometryFor(p, g, gate) {
  return edgeEffective(p.filmEdge, gate) || dateEffective(p.dateBack, p.filmEdge, gate) && !isIdentity(g) ? g : null;
}
function canvasGeometryFor(p, g, gate) {
  return sourceGeometryFor(p, g, gate) ? GEOMETRY_DEFAULT : g;
}
function gateFramed(g, edge, size, landscape) {
  const f = edgeFormat(edge.format);
  if (!f || !(size.width > 0 && size.height > 0)) return g;
  const along = edge.pair ? 37 : f.long, across = edge.pair ? 24 : f.short;
  const horizontal = landscape ?? g.crop.width * size.width >= g.crop.height * size.height;
  return constrained({ ...g, lockedRatio: horizontal ? along / across : across / along }, size);
}
function framingKey(g) {
  const c = g.crop;
  return [
    c.x.toFixed(6),
    c.y.toFixed(6),
    c.width.toFixed(6),
    c.height.toFixed(6),
    g.angle.toFixed(4),
    (g.quarterTurns % 4 + 4) % 4,
    Number(g.flipH),
    Number(g.flipV)
  ].join(",");
}
function captureDate(text, order) {
  const match = /^(\d{4})[:-](\d{2})[:-](\d{2})(?:[T\s]|$)/.exec(text ?? "");
  if (!match) return "";
  const [year, month, day] = match.slice(1).map(Number);
  if (year <= 1800 || month < 1 || month > 12 || day < 1 || day > new Date(Date.UTC(year, month, 0)).getUTCDate()) return "";
  const yy = `'${String(year % 100).padStart(2, "0")}`;
  return order === "us" ? `${month} ${day} ${yy}` : `${yy} ${month} ${day}`;
}
function shootingText(m) {
  if (!m) return "";
  const extra = m;
  const trim = (n) => n.toFixed(1).replace(/\.0$/, "");
  const fields2 = [];
  if (m.shutter_s && Number.isFinite(m.shutter_s) && m.shutter_s > 0)
    fields2.push(m.shutter_s >= 1 ? `${trim(m.shutter_s)}s` : `1/${Math.round(1 / m.shutter_s)}`);
  if (m.aperture && Number.isFinite(m.aperture) && m.aperture > 0) fields2.push(`F${trim(m.aperture)}`);
  const mode = { 1: "M", 2: "P", 3: "A", 4: "S" }[extra.exposure_program ?? 0];
  if (mode) fields2.push(mode);
  if (Number.isFinite(extra.exposure_bias_ev)) {
    const b = Math.round(extra.exposure_bias_ev * 10) / 10;
    if (b !== 0) fields2.push(`${b > 0 ? "+" : ""}${b.toFixed(1)}`);
  }
  if (extra.focal_35mm && Number.isFinite(extra.focal_35mm) && extra.focal_35mm > 0) fields2.push(`${Math.round(extra.focal_35mm)}mm`);
  while (fields2.join(" ").length > 22) fields2.pop();
  return fields2.join(" ");
}
var EDGE_WORDS = {
  kodak_gold_200: ["KODAK GB 200-7", "KODAK 200"],
  kodak_portra_800: ["KODAK PORTRA 800-3", "KODAK PORTRA 800"],
  kodak_portra_800_push1: ["KODAK PORTRA 800-3", "KODAK PORTRA 800"],
  kodak_portra_800_push2: ["KODAK PORTRA 800-3", "KODAK PORTRA 800"],
  kodak_ultramax_400: ["KODAK GC 400"],
  kodak_ektachrome_100: ["KODAK E100"],
  fujifilm_c200: ["FUJI 200"],
  fujifilm_xtra_400: ["S-400", "FUJI S-400"],
  fujifilm_pro_400h: ["PRO400H", "FUJI PRO400H"],
  fujifilm_provia_100f: ["FUJI RDPIII"],
  fujifilm_velvia_100: ["RVP100", "FUJI RVP100"],
  kodak_vision3_50d: ["EASTMAN 5203"],
  kodak_vision3_250d: ["EASTMAN 5207"],
  kodak_vision3_200t: ["EASTMAN 5213"],
  kodak_vision3_500t: ["EASTMAN 5219"],
  kodak_tri_x_400: ["KODAK 400TX"],
  kodak_tmax_100: ["KODAK 100TMX"],
  fujifilm_neopan_acros_100_ii: ["FUJI 100 ACROS II"],
  ilford_hp5_plus_400: ["ILFORD HP5 PLUS"]
};
function edgeText(stock, format) {
  if (!stock) return "";
  const own = EDGE_WORDS[stock.id];
  return own ? edgeFormat(format)?.gauge === "120" ? own[1] ?? own[0] : own[0] : stock.name.split("(")[0].trim().toUpperCase();
}
function resolveFilmEdgeParams(p, geometry, metadata, catalog, native) {
  const dataText = shootingText(metadata), f = p.filmEdge;
  const sourceAspect = native ? Math.max(native.width, native.height) / Math.max(1, Math.min(native.width, native.height)) : 1.5;
  const camera = edgeEffective(f) ? f.format : EDGE_FORMATS.filter((v) => ["135", "135_half", "120_645"].includes(v.id)).find((v) => Math.abs(v.long - p.filmFormatMM) <= 1 && Math.abs(v.short - p.filmFormatMM / sourceAspect) <= 1)?.id ?? null;
  const cut = native ? outputSize(geometry, native) : null;
  return { ...p, filmEdge: {
    ...f,
    edgeText: edgeText(catalog.stock(p.filmStock), f.format),
    fNumber: metadata?.aperture ?? 0,
    framing: framingKey(geometry)
  }, dateBack: {
    ...p.dateBack,
    camera,
    dataText,
    text: p.dateBack.face === "data" ? dataText : captureDate(metadata?.datetime_original, p.dateBack.order),
    framing: isIdentity(geometry) ? "" : framingKey(geometry),
    frameScale: cut && native ? Math.max(cut.width, cut.height) / Math.max(native.width, native.height) : 1
  } };
}
function filmFormatForWire(p, gate) {
  return !edgeEffective(p.filmEdge, gate) && dateEffective(p.dateBack, p.filmEdge, gate) && p.dateBack.framing ? p.filmFormatMM * p.dateBack.frameScale : p.filmFormatMM;
}
function dateScale(p, gate) {
  const camera = dateCamera(p.dateBack, p.filmEdge, gate);
  return !edgeEffective(p.filmEdge, gate) && dateEffective(p.dateBack, p.filmEdge, gate) && p.dateBack.framing && camera ? Math.max(0.05, Math.min(1, filmFormatForWire(p, gate) / camera.long)) : 1;
}

// src/shared/params.ts
var clamp = (v, lo, hi) => v < lo ? lo : v > hi ? hi : v;
var FILM_FRAMES_CINE = [
  { id: "Super 8", short: 4.01, long: 5.79, isCine: true },
  { id: "16mm", short: 7.49, long: 10.26, isCine: true },
  { id: "Super 16", short: 7.41, long: 12.52, isCine: true },
  { id: "Super 35", short: 14, long: 24.89, isCine: true },
  { id: "65mm", short: 23.01, long: 52.63, isCine: true }
];
var FILM_FRAME_CUSTOM = { id: "Custom", short: 24, long: 36, isCine: false };
var FILM_FRAMES_STILL = [
  { id: "110", short: 13, long: 17, isCine: false },
  { id: "APS", short: 16.7, long: 30.2, isCine: false },
  { id: "135", short: 24, long: 36, isCine: false },
  { id: "120", short: 56, long: 56, isCine: false },
  FILM_FRAME_CUSTOM
];
var FILM_FRAMES = [...FILM_FRAMES_CINE, ...FILM_FRAMES_STILL];
var filmFrameNamed = (id) => FILM_FRAMES.find((f) => f.id === id) ?? FILM_FRAME_CUSTOM;
function filmFormatMM(side, sideLengthMM, aspect, cropScale = 1) {
  const long = side === "long" ? sideLengthMM : sideLengthMM * Math.max(aspect, 1);
  return clamp(long * Math.max(cropScale, 1), 4, 200);
}
var EXPOSURE_METHODS = ["balanced", "center", "protect_highlights", "protect_shadows"];
var CONTRAST_MASK_DEFAULT = {
  active: false,
  highlights: 0,
  shadows: 0,
  core: 1,
  scale: 0.03,
  scheme: "gaussian"
};
var CONTRAST_MASK_SCALE = [2e-3, 0.12];
var SCENE_LATITUDE_DEFAULT = {
  highlightPullBack: 0,
  shadowPullBack: 0,
  shadowPercentile: 0.1,
  highlightPercentile: 99.9,
  active: false,
  norm: "power",
  highlightKnee: 2,
  highlightRoom: 0,
  shadowKnee: -2,
  shadowRoom: 0,
  rolloff: 2,
  maxLift: 4
};
var EFFECTS_DEFAULT = {
  grain: 1,
  grainLayered: true,
  halation: 1,
  antihalationRemoved: false,
  highlightBoost: 0,
  scatter: 1,
  couplersActive: true,
  couplers: 1,
  glare: 1
};
var EFFECT_RANGES = {
  grain: [0, 2],
  halation: [0, 4],
  scatter: [0, 1],
  highlightBoost: [0, 8],
  // Not the wire's 0…4: above ≈1.736 the coupler inverse is not monotonic
  // (AGENTS.md trap 22), so the slider stops short of it.
  couplers: [0, 1.5],
  glare: [0, 30]
};
var FILM_EDGE_FORMATS = [
  "135",
  "135_half",
  "135_xpan",
  "120_645",
  "120_6x6",
  "120_6x7",
  "120_6x8",
  "120_6x9",
  "120_6x12",
  "120_6x17"
];
var FILM_EDGE_DEFAULT = {
  active: false,
  format: "135",
  view: "strip",
  gate: "auto",
  holes: "white",
  cameraSeed: 1,
  frameSeed: 1,
  frameNumber: 0,
  fog: 1,
  leaks: 0,
  edgeText: "",
  fNumber: 0,
  framing: "",
  pair: false,
  seeded: false
};
var DATE_BACK_DEFAULT = {
  active: false,
  face: "lcd",
  order: "japan",
  placement: "frame",
  corner: "br",
  insetXMM: 3,
  insetYMM: 2.4,
  size: 1,
  brightnessEV: 3.5,
  text: "",
  textB: "",
  withData: false,
  dataText: "",
  customText: null,
  camera: "135",
  framing: "",
  frameScale: 1
};
var FILM_PARAMS_DEFAULT = {
  filmStock: "kodak_portra_400",
  printStock: "kodak_supra_endura",
  exposureCompensationEV: 0,
  autoExposureMethod: "balanced",
  autoExposure: true,
  filmFormatMM: 36,
  filmFrame: "135",
  filmSide: "short",
  sideLengthMM: 24,
  grainActive: true,
  halationActive: true,
  printBrightnessStops: 0,
  yFilterShift: 0,
  mFilterShift: 0,
  glareActive: true,
  scanFilm: false,
  digitalIntermediate: false,
  extendedDynamicRange: false,
  preflashExposure: 0,
  contrastMask: CONTRAST_MASK_DEFAULT,
  sceneLatitude: SCENE_LATITUDE_DEFAULT,
  sceneLatitudeOther: SCENE_LATITUDE_DEFAULT,
  placementIsRight: false,
  pairSplit: 0,
  effects: EFFECTS_DEFAULT,
  printEffects: true,
  filmEdge: FILM_EDGE_DEFAULT,
  dateBack: DATE_BACK_DEFAULT
};
var FILTER_SHIFT_CC = 40;
var printExposure = (stops) => clamp(Math.pow(2, -stops), 0.05, 20);
function obj(v) {
  return v && typeof v === "object" && !Array.isArray(v) ? v : {};
}
function decodeShape(raw, d) {
  const o = obj(raw);
  const out = { ...d };
  for (const k of Object.keys(d)) {
    const v = o[k];
    const dv = d[k];
    if (v === void 0) continue;
    if (dv === null || dv === void 0) {
      if (v === null || typeof v === "string" || typeof v === "number") out[k] = v;
    } else if (typeof v === typeof dv) out[k] = v;
  }
  return out;
}
function decodeFilmParams(raw) {
  const o = obj(raw);
  const base = decodeShape(o, FILM_PARAMS_DEFAULT);
  base.autoExposureMethod = "autoExposureMethod" in o ? typeof o.autoExposureMethod === "string" ? o.autoExposureMethod : null : null;
  if (!("filmStock" in o)) base.autoExposureMethod = FILM_PARAMS_DEFAULT.autoExposureMethod;
  base.filmSide = base.filmSide === "long" ? "long" : "short";
  base.contrastMask = decodeShape(o.contrastMask, CONTRAST_MASK_DEFAULT);
  base.sceneLatitude = decodeShape(o.sceneLatitude, SCENE_LATITUDE_DEFAULT);
  base.sceneLatitudeOther = decodeShape(o.sceneLatitudeOther, SCENE_LATITUDE_DEFAULT);
  base.effects = decodeShape(o.effects, EFFECTS_DEFAULT);
  base.filmEdge = decodeShape(o.filmEdge, FILM_EDGE_DEFAULT);
  base.dateBack = decodeShape(o.dateBack, DATE_BACK_DEFAULT);
  if (o.filmEdge && !("seeded" in obj(o.filmEdge))) base.filmEdge.seeded = "frameSeed" in obj(o.filmEdge);
  return base;
}
var ALL_FEATURES = {
  digitalIntermediate: true,
  sceneLatitude: true,
  contrastMask: true,
  overscan: true,
  dateImprint: true,
  diBlueCompensation: false,
  toneMask: false
};
function featureGate(unsupported, diBlue = false) {
  const u = new Set(unsupported ?? []);
  return {
    digitalIntermediate: !u.has("digital_intermediate"),
    sceneLatitude: !u.has("scene_latitude_mapping"),
    contrastMask: !u.has("contrast_mask"),
    overscan: !u.has("overscan"),
    dateImprint: !u.has("date_imprint"),
    diBlueCompensation: diBlue,
    toneMask: false
  };
}
function effectiveEDR(p, catalog) {
  return p.extendedDynamicRange && !p.scanFilm && !p.digitalIntermediate && !catalog?.isMonochrome(p.printStock);
}
function normalizeStockPair(p, catalog) {
  const scanFilm = p.scanFilm || catalog.isPositive(p.filmStock);
  let printStock = p.printStock;
  if (!catalog.canPrint(p.filmStock, printStock)) {
    const target = catalog.stock(p.filmStock)?.targetPrint;
    const defaultPaper = FILM_PARAMS_DEFAULT.printStock;
    const replacement = target && catalog.stock(target) && catalog.canPrint(p.filmStock, target) ? target : catalog.stock(defaultPaper) && catalog.canPrint(p.filmStock, defaultPaper) ? defaultPaper : catalog.papers.find((paper) => catalog.canPrint(p.filmStock, paper.id))?.id;
    if (replacement) printStock = replacement;
  }
  return scanFilm === p.scanFilm && printStock === p.printStock ? p : { ...p, scanFilm, printStock };
}
function ownGrain(stock) {
  switch (stock) {
    case "kodak_tri_x_400":
      return 1.7;
    case "ilford_hp5_plus_400":
      return 1.49;
    case "kodak_tmax_100":
      return 0.74;
    case "fujifilm_neopan_acros_100_ii":
      return 0.64;
    default:
      return 1;
  }
}
function wire(p, gate = ALL_FEATURES, catalog) {
  const di = gate.digitalIntermediate && p.digitalIntermediate;
  const placement = p.placementIsRight ? p.sceneLatitudeOther : p.sceneLatitude;
  const f = [
    { name: "film_stock", value: p.filmStock, layer: "shoot" },
    { name: "print_stock", value: p.printStock, layer: "print" },
    { name: "exposure_compensation_ev", value: p.exposureCompensationEV, layer: "shoot" }
  ];
  if (p.autoExposureMethod != null) f.push({ name: "auto_exposure_method", value: p.autoExposureMethod, layer: "shoot" });
  f.push(
    { name: "auto_exposure", value: p.autoExposure, layer: "shoot" },
    { name: "film_format_mm", value: clamp(filmFormatForWire(p, gate), 4, 200), layer: "shoot" },
    { name: "grain_active", value: p.grainActive, layer: "shoot" },
    { name: "grain_sublayers_active", value: p.grainActive && p.effects.grainLayered && !catalog?.isMonochrome(p.filmStock), layer: "shoot" },
    { name: "halation_active", value: p.halationActive, layer: "shoot" },
    { name: "print_exposure", value: printExposure(p.printBrightnessStops), layer: "print" },
    { name: "y_filter_shift", value: clamp(p.yFilterShift, -1, 1), layer: "print" },
    { name: "m_filter_shift", value: clamp(p.mFilterShift, -1, 1), layer: "print" },
    { name: "filter_shift_scale", value: FILTER_SHIFT_CC, layer: "print" },
    { name: "glare_active", value: p.glareActive && p.printEffects, layer: "print" },
    { name: "scan_film", value: p.scanFilm, layer: "print" },
    { name: "extended_dynamic_range", value: effectiveEDR(p, catalog), layer: "print" },
    { name: "preflash_exposure", value: p.printEffects ? clamp(p.preflashExposure, 0, 1) : 0, layer: "print" }
  );
  if (gate.contrastMask) {
    f.push(
      {
        name: "contrast_mask_active",
        value: p.contrastMask.active && p.printEffects && gate.toneMask,
        layer: "print"
      },
      { name: "contrast_mask_highlights", value: p.contrastMask.highlights, layer: "print" },
      { name: "contrast_mask_shadows", value: p.contrastMask.shadows, layer: "print" },
      { name: "contrast_mask_core", value: p.contrastMask.core, layer: "print" },
      {
        name: "contrast_mask_scale",
        value: clamp(p.contrastMask.scale, CONTRAST_MASK_SCALE[0], CONTRAST_MASK_SCALE[1]),
        layer: "print"
      },
      { name: "contrast_mask_scheme", value: p.contrastMask.scheme, layer: "print" }
    );
  }
  if (gate.sceneLatitude) {
    f.push(
      { name: "scene_latitude_active", value: placement.active && !(di && !p.scanFilm), layer: "shoot" },
      { name: "scene_latitude_norm", value: placement.norm, layer: "shoot" },
      { name: "scene_latitude_highlight_knee", value: placement.highlightKnee, layer: "shoot" },
      { name: "scene_latitude_highlight_room", value: placement.highlightRoom, layer: "shoot" },
      { name: "scene_latitude_shadow_knee", value: placement.shadowKnee, layer: "shoot" },
      { name: "scene_latitude_shadow_room", value: placement.shadowRoom, layer: "shoot" },
      { name: "scene_latitude_rolloff", value: placement.rolloff, layer: "shoot" },
      { name: "scene_latitude_max_lift", value: placement.maxLift, layer: "shoot" },
      { name: "scene_latitude_split", value: p.filmEdge.pair ? clamp(p.pairSplit, 0, 1) : 0, layer: "shoot" }
    );
    if (p.filmEdge.pair) {
      const second = p.placementIsRight ? p.sceneLatitude : p.sceneLatitudeOther;
      f.push(
        { name: "scene_latitude_b_active", value: second.active && !(di && !p.scanFilm), layer: "shoot" },
        { name: "scene_latitude_b_highlight_knee", value: second.highlightKnee, layer: "shoot" },
        { name: "scene_latitude_b_highlight_room", value: second.highlightRoom, layer: "shoot" },
        { name: "scene_latitude_b_shadow_knee", value: second.shadowKnee, layer: "shoot" },
        { name: "scene_latitude_b_shadow_room", value: second.shadowRoom, layer: "shoot" }
      );
    }
  }
  const e = p.effects;
  const r = EFFECT_RANGES;
  f.push(
    { name: "halation_amount", value: clamp(e.halation, r.halation[0], r.halation[1]), layer: "shoot" },
    { name: "halation_scatter_amount", value: clamp(e.scatter, r.scatter[0], r.scatter[1]), layer: "shoot" },
    { name: "grain_amount", value: clamp(e.grain * ownGrain(p.filmStock), r.grain[0], r.grain[1]), layer: "shoot" },
    { name: "dir_couplers_active", value: e.couplersActive, layer: "shoot" },
    { name: "dir_couplers_amount", value: clamp(e.couplers, r.couplers[0], r.couplers[1]), layer: "shoot" },
    { name: "glare_amount", value: clamp(e.glare, r.glare[0], r.glare[1]), layer: "print" },
    { name: "antihalation_removed", value: e.antihalationRemoved, layer: "shoot" },
    { name: "halation_boost_ev", value: clamp(e.highlightBoost, r.highlightBoost[0], r.highlightBoost[1]), layer: "shoot" }
  );
  if (catalog?.isMonochrome(p.filmStock) && catalog.isMonochrome(p.printStock)) {
    f.push(
      { name: "c_filter_neutral", value: 0, layer: "print" },
      { name: "m_filter_neutral", value: 0, layer: "print" },
      { name: "y_filter_neutral", value: 68, layer: "print" }
    );
  }
  if (gate.digitalIntermediate) {
    f.push(
      { name: "digital_intermediate", value: p.digitalIntermediate, layer: "print" },
      {
        name: "digital_intermediate_blue_compensation",
        value: p.digitalIntermediate && gate.diBlueCompensation,
        layer: "print"
      }
    );
  }
  if (gate.overscan) {
    const fe = p.filmEdge;
    f.push({ name: "overscan_active", value: edgeEffective(fe, gate), layer: "shoot" });
    f.push({ name: "overscan_pair", value: fe.pair, layer: "shoot" });
    if (edgeEffective(fe, gate)) {
      f.push(
        { name: "overscan_format", value: fe.format, layer: "shoot" },
        { name: "overscan_mode", value: fe.view, layer: "shoot" },
        { name: "overscan_gate", value: fe.gate, layer: "shoot" },
        { name: "overscan_holes", value: fe.holes, layer: "shoot" },
        { name: "overscan_camera_seed", value: clamp(Math.round(fe.cameraSeed), 0, 2147483647), layer: "shoot" },
        { name: "overscan_frame_seed", value: clamp(Math.round(fe.frameSeed), 0, 2147483647), layer: "shoot" },
        { name: "overscan_frame_number", value: clamp(Math.round(fe.frameNumber), 0, 99), layer: "shoot" },
        { name: "overscan_fog", value: clamp(fe.fog, 0, 4), layer: "shoot" },
        { name: "overscan_leaks", value: clamp(fe.leaks, 0, 4), layer: "shoot" },
        { name: "overscan_edge_text", value: fe.edgeText, layer: "shoot" },
        { name: "overscan_f_number", value: clamp(fe.fNumber, 0, 64), layer: "shoot" }
      );
    }
  }
  if (gate.dateImprint) {
    const d = p.dateBack;
    const on = dateEffective(d, p.filmEdge, gate), camera = dateCamera(d, p.filmEdge, gate), scale = dateScale(p, gate);
    f.push({ name: "date_imprint_active", value: on, layer: "shoot" });
    if (on) {
      if (!(gate.overscan && p.filmEdge.active))
        f.push({ name: "overscan_format", value: d.camera ?? "135", layer: "shoot" });
      f.push(
        { name: "date_imprint_style", value: d.face, layer: "shoot" },
        { name: "date_imprint_text", value: d.customText ?? d.text, layer: "shoot" },
        { name: "date_imprint_text_b", value: p.filmEdge.pair ? d.textB : "", layer: "shoot" },
        { name: "date_imprint_placement", value: d.placement, layer: "shoot" },
        { name: "date_imprint_corner", value: d.corner, layer: "shoot" },
        { name: "date_imprint_inset_x", value: clamp(d.insetXMM * scale, 0, 30), layer: "shoot" },
        { name: "date_imprint_inset_y", value: clamp(d.insetYMM * scale, 0, 30), layer: "shoot" },
        { name: "date_imprint_size", value: clamp((d.face === "data" && camera?.id === "135_half" ? Math.min(d.size, 1) : d.size) * scale, 0.4, 3), layer: "shoot" },
        { name: "date_imprint_ev", value: clamp(d.brightnessEV, -2, 8), layer: "shoot" },
        { name: "date_imprint_data_text", value: d.withData && d.face !== "data" && datePrints("data", d, p.filmEdge, gate) ? d.dataText : "", layer: "shoot" }
      );
    }
  }
  return f;
}
function fullDelta(p, gate, catalog) {
  const out = {};
  for (const f of wire(p, gate, catalog)) out[f.name] = f.value;
  return out;
}

// src/shared/adjustments.ts
var ZONE = { hue: 0, saturation: 0, luminance: 0 };
var CURVE_IDENTITY = {
  points: [
    [0, 0],
    [1, 1]
  ]
};
var CURVES_IDENTITY = {
  rgb: CURVE_IDENTITY,
  luma: CURVE_IDENTITY,
  red: CURVE_IDENTITY,
  green: CURVE_IDENTITY,
  blue: CURVE_IDENTITY
};
var ADJUSTMENTS_DEFAULT = {
  enabled: true,
  temperature: 0,
  tint: 0,
  exposure: 0,
  contrast: 0,
  brightness: 0,
  saturation: 0,
  highlights: 0,
  shadows: 0,
  blackPoint: 0,
  whitePoint: 0,
  curves: CURVES_IDENTITY,
  colorBalance: { master: ZONE, shadows: ZONE, midtones: ZONE, highlights: ZONE },
  vignette: { amount: 0, midpoint: 50 }
};
function obj2(v) {
  return v && typeof v === "object" && !Array.isArray(v) ? v : {};
}
var num = (v, d) => typeof v === "number" && Number.isFinite(v) ? v : d;
function decodeCurve(v) {
  const pts = obj2(v).points;
  if (!Array.isArray(pts) || pts.length < 2) return CURVE_IDENTITY;
  const points = [];
  for (const p of pts) {
    if (Array.isArray(p) && p.length === 2) points.push([num(p[0], 0), num(p[1], 0)]);
    else if (p && typeof p === "object") points.push([num(p.x, 0), num(p.y, 0)]);
  }
  return points.length >= 2 ? { points } : CURVE_IDENTITY;
}
function decodeZone(v) {
  const o = obj2(v);
  return { hue: num(o.hue, 0), saturation: num(o.saturation, 0), luminance: num(o.luminance, 0) };
}
function decodeAdjustments(raw) {
  const o = obj2(raw);
  const d = ADJUSTMENTS_DEFAULT;
  const c = obj2(o.curves);
  const cb = obj2(o.colorBalance);
  const v = obj2(o.vignette);
  return {
    enabled: typeof o.enabled === "boolean" ? o.enabled : true,
    temperature: num(o.temperature, d.temperature),
    tint: num(o.tint, d.tint),
    exposure: num(o.exposure, d.exposure),
    contrast: num(o.contrast, d.contrast),
    brightness: num(o.brightness, d.brightness),
    saturation: num(o.saturation, d.saturation),
    highlights: num(o.highlights, d.highlights),
    shadows: num(o.shadows, d.shadows),
    blackPoint: num(o.blackPoint, d.blackPoint),
    whitePoint: num(o.whitePoint, d.whitePoint),
    curves: {
      rgb: decodeCurve(c.rgb),
      luma: decodeCurve(c.luma),
      red: decodeCurve(c.red),
      green: decodeCurve(c.green),
      blue: decodeCurve(c.blue)
    },
    colorBalance: {
      master: decodeZone(cb.master),
      shadows: decodeZone(cb.shadows),
      midtones: decodeZone(cb.midtones),
      highlights: decodeZone(cb.highlights)
    },
    vignette: { amount: num(v.amount, 0), midpoint: num(v.midpoint, 50) }
  };
}

// src/shared/sidecar.ts
var DECODE_DEFAULT = {
  whiteBalance: "As Shot",
  temperature: 5500,
  tint: 0,
  lensCorrection: false
};
function newSidecar() {
  return {
    schemaVersion: 3,
    decoder: "libraw",
    decode: DECODE_DEFAULT,
    params: FILM_PARAMS_DEFAULT,
    adjustments: ADJUSTMENTS_DEFAULT,
    geometry: GEOMETRY_DEFAULT,
    solvedEV: null,
    placementNeedsFit: false,
    state: "unprocessed",
    raw: {}
  };
}
function decodeState(v) {
  if (typeof v === "string" && ["unprocessed", "processed", "stale"].includes(v)) return v;
  if (v && typeof v === "object") {
    const k = Object.keys(v)[0];
    if (k === "processed" || k === "stale" || k === "unprocessed") return k;
  }
  return "unprocessed";
}
function decodeSidecar(raw) {
  const o = raw && typeof raw === "object" && !Array.isArray(raw) ? raw : {};
  const d = o.decode && typeof o.decode === "object" ? o.decode : {};
  let geometry = GEOMETRY_DEFAULT;
  if (o.geometry) geometry = decodeGeometry(o.geometry);
  else if (o.crop) geometry = decodeGeometry({ crop: o.crop });
  return {
    schemaVersion: 3,
    decoder: typeof o.decoder === "string" ? o.decoder : "coreimage",
    decode: {
      whiteBalance: typeof d.whiteBalance === "string" ? d.whiteBalance : DECODE_DEFAULT.whiteBalance,
      temperature: typeof d.temperature === "number" ? d.temperature : DECODE_DEFAULT.temperature,
      tint: typeof d.tint === "number" ? d.tint : DECODE_DEFAULT.tint,
      lensCorrection: d.lensCorrection === true
    },
    params: o.params ? decodeFilmParams(o.params) : FILM_PARAMS_DEFAULT,
    adjustments: o.adjustments ? decodeAdjustments(o.adjustments) : ADJUSTMENTS_DEFAULT,
    geometry,
    heldCrop: o.heldCrop ? decodeGeometry(o.heldCrop) : null,
    solvedEV: typeof o.solvedEV === "number" ? o.solvedEV : null,
    placementNeedsFit: o.placementNeedsFit === true,
    state: decodeState(o.state),
    raw: o
  };
}
function encodeSidecar(s) {
  const out = { ...s.raw };
  delete out.crop;
  out.schemaVersion = 3;
  out.decoder = s.decoder;
  out.decode = s.decode;
  out.params = s.params;
  out.adjustments = s.adjustments;
  out.geometry = encodeGeometry(s.geometry);
  if (s.heldCrop) out.heldCrop = encodeGeometry(s.heldCrop);
  else delete out.heldCrop;
  if (s.solvedEV != null) out.solvedEV = s.solvedEV;
  else delete out.solvedEV;
  if (s.placementNeedsFit) out.placementNeedsFit = true;
  else delete out.placementNeedsFit;
  out.state = { [s.state]: {} };
  return out;
}

// src/shared/fileTypes.ts
var RAW_EXTENSIONS = [
  "3fr",
  "ari",
  "arw",
  "bay",
  "cr2",
  "cr3",
  "crw",
  "dcr",
  "dng",
  "erf",
  "fff",
  "gpr",
  "iiq",
  "k25",
  "kdc",
  "mef",
  "mos",
  "mrw",
  "nef",
  "nrw",
  "orf",
  "pef",
  "raf",
  "raw",
  "rw2",
  "rwl",
  "sr2",
  "srf",
  "srw",
  "x3f"
];
var RASTER_EXTENSIONS = ["tif", "tiff", "jpg", "jpeg", "png", "heic", "heif", "hif", "exr"];
var PHOTO_PICKER_EXTENSIONS = [...RAW_EXTENSIONS, ...RASTER_EXTENSIONS].flatMap((ext) => [ext, ext.toUpperCase()]);

// src/shared/whiteBalance.ts
var WB_MODES = ["As Shot", "Daylight", "Cloudy", "Shade", "Tungsten", "Fluorescent", "Custom"];
var WB_KELVIN = {
  Daylight: 5500,
  Cloudy: 6500,
  Shade: 7500,
  Tungsten: 3200,
  Fluorescent: 4e3
};
function modeOf(d) {
  return WB_MODES.includes(d.whiteBalance) ? d.whiteBalance : "As Shot";
}
var RAW_EXT = new Set(RAW_EXTENSIONS);
function isRawPath(path2) {
  return RAW_EXT.has((path2.split(".").pop() ?? "").toLowerCase());
}
function decodeWire(d, isRaw) {
  if (!isRaw) return null;
  const lens = d.lensCorrection ? { lens_correction: true } : {};
  if (modeOf(d) === "As Shot") return { white_balance: { mode: "as_shot" }, ...lens };
  const clamp2 = (v, lo, hi) => Math.min(hi, Math.max(lo, v));
  return { white_balance: { mode: "custom", temperature_k: clamp2(d.temperature, 2e3, 5e4), tint: clamp2(d.tint, -150, 150) }, ...lens };
}

// agent/schema.ts
var Refused = class extends Error {
  refused = true;
};
function document(s) {
  return structuredClone({ params: s.params, adjustments: s.adjustments, geometry: s.geometry, decode: s.decode });
}
function fields(catalog) {
  const out = /* @__PURE__ */ new Map();
  const add = (path2, type, range, choices) => out.set(path2, { path: path2, type, doc: path2.replaceAll(".", " / "), ...range ? { min: range[0], max: range[1] } : {}, ...choices ? { enum: choices } : {} });
  const numbers = (prefix, entries) => Object.entries(entries).forEach(([key, r]) => add(`${prefix}.${key}`, "number", r));
  const bools = (prefix, keys) => keys.split(" ").forEach((k) => add(`${prefix}.${k}`, "boolean"));
  add("params.filmStock", "string", void 0, catalog.films.map((s) => s.id));
  add("params.printStock", "string", void 0, catalog.papers.map((s) => s.id));
  numbers("params", { exposureCompensationEV: [-4, 4], sideLengthMM: [1, 500], printBrightnessStops: [-3, 3], yFilterShift: [-1, 1], mFilterShift: [-1, 1], preflashExposure: [0, 0.03] });
  bools("params", "autoExposure grainActive halationActive glareActive scanFilm digitalIntermediate extendedDynamicRange printEffects");
  add("params.autoExposureMethod", "string", void 0, EXPOSURE_METHODS);
  add("params.filmFrame", "string", void 0, [...FILM_FRAMES.map((f) => f.id), "Custom"]);
  add("params.filmSide", "string", void 0, ["short", "long"]);
  numbers("params.effects", EFFECT_RANGES);
  bools("params.effects", "grainLayered antihalationRemoved couplersActive");
  bools("params.filmEdge", "active");
  add("params.filmEdge.format", "string", void 0, FILM_EDGE_FORMATS);
  for (const [key, values] of Object.entries({ view: ["strip", "carrier"], gate: ["auto", "square", "rounded", "eared", "shouldered", "kicked"], holes: ["white", "black"] })) add(`params.filmEdge.${key}`, "string", void 0, values);
  for (const key of ["cameraSeed", "frameSeed"]) add(`params.filmEdge.${key}`, "integer", [0, 2147483647]);
  add("params.filmEdge.frameNumber", "integer", [0, 99]);
  numbers("params.filmEdge", { fog: [0, 4], leaks: [0, 4] });
  bools("params.dateBack", "active withData");
  for (const [key, values] of Object.entries({ face: ["lcd", "dots", "data"], order: ["us", "japan"], placement: ["frame", "rebate"], corner: ["tl", "tr", "bl", "br"] })) add(`params.dateBack.${key}`, "string", void 0, values);
  numbers("params.dateBack", { insetXMM: [0, 30], insetYMM: [0, 30], size: [0.4, 3], brightnessEV: [-2, 8] });
  bools("adjustments", "enabled");
  numbers("adjustments", { temperature: [-100, 100], tint: [-100, 100], exposure: [-3, 3], contrast: [-50, 50], brightness: [-50, 50], saturation: [-100, 100], highlights: [-100, 100], shadows: [-100, 100], blackPoint: [0, 50], whitePoint: [0, 50] });
  numbers("adjustments.vignette", { amount: [-100, 100], midpoint: [0, 100] });
  for (const c of ["rgb", "luma", "red", "green", "blue"]) add(`adjustments.curves.${c}.points`, "points");
  for (const z of ["master", "shadows", "midtones", "highlights"]) numbers(`adjustments.colorBalance.${z}`, { hue: [0, 360], saturation: [0, 1], luminance: [-1, 1] });
  numbers("geometry.crop", { x: [0, 1], y: [0, 1], width: [0, 1], height: [0, 1] });
  numbers("geometry", { angle: [-45, 45] });
  add("geometry.quarterTurns", "integer", [0, 3]);
  bools("geometry", "flipH flipV");
  add("geometry.aspect", "string", void 0, ["free", "original", "originalPortrait", "square", "r3x2", "r2x3", "r4x3", "r3x4", "r16x9", "r9x16", "r5x4", "r4x5", "r7x5", "r5x7"]);
  add("decode.whiteBalance", "string", void 0, WB_MODES);
  numbers("decode", { temperature: [2e3, 12e3], tint: [-150, 150] });
  bools("decode", "lensCorrection");
  function walk(v, path2) {
    if (out.has(path2)) return;
    if (v && typeof v === "object" && !Array.isArray(v)) for (const [k, x] of Object.entries(v)) walk(x, path2 ? `${path2}.${k}` : k);
    else out.set(path2, { path: path2, type: typeof v, doc: path2, readOnly: path2.startsWith("params.sceneLatitude") ? "Use place_scene: a solved placement must pass the engine Fit." : path2.startsWith("params.contrastMask") ? "Tone Mask is withdrawn in this version." : "Derived by the application." });
  }
  walk(document(newSidecar()), "");
  for (const key of ["geometry.lockedRatio", "geometry.intendedSize"]) if (!out.has(key)) out.set(key, { path: key, type: "derived", doc: key, readOnly: "Derived by crop and film edge." });
  return [...out.values()];
}
function validate(patch, catalog) {
  const map = new Map(fields(catalog).map((f) => [f.path, f])), leaves = [];
  const branches = new Set([...map.keys()].flatMap((p) => p.split(".").slice(0, -1).map((_, i) => p.split(".").slice(0, i + 1).join("."))));
  const object = (x) => !!x && typeof x === "object" && !Array.isArray(x);
  if (!object(patch)) throw new Refused("The patch must be an object.");
  function walk(v, path2) {
    const f = map.get(path2);
    if (!f) {
      if (!branches.has(path2) || !object(v)) throw new Refused(`${path2} is not an editable field or object.`);
      for (const [k, x] of Object.entries(v)) walk(x, `${path2}.${k}`);
      return;
    }
    if (f.readOnly) throw new Refused(`${path2} is read-only: ${f.readOnly}`);
    if (f.type === "points") {
      if (!Array.isArray(v) || v.length < 2 || v.length > 256 || v.some((p) => !Array.isArray(p) || p.length !== 2 || p.some((x) => typeof x !== "number" || !Number.isFinite(x) || x < 0 || x > 1)) || v[0][0] !== 0 || v.at(-1)[0] !== 1 || v.some((p, i) => i > 0 && p[0] <= v[i - 1][0])) throw new Refused(`${path2} needs 2\u2013256 ascending [x,y] points within 0..1, starting 0 ending 1.`);
    } else if (f.type === "number" || f.type === "integer") {
      if (typeof v !== "number" || !Number.isFinite(v) || f.type === "integer" && !Number.isInteger(v) || v < f.min || v > f.max) throw new Refused(`${path2} must be ${f.type} in ${f.min}..${f.max}.`);
    } else if (typeof v !== f.type || f.enum && !f.enum.includes(v)) throw new Refused(`${path2} must be ${f.enum?.join(", ") ?? f.type}.`);
    leaves.push(path2);
  }
  for (const [k, v] of Object.entries(patch)) walk(v, k);
  return leaves;
}
function merge(original, patch) {
  if (!patch || typeof patch !== "object" || Array.isArray(patch)) return structuredClone(patch);
  const out = structuredClone(original);
  for (const [k, v] of Object.entries(patch)) {
    if (k === "__proto__" || k === "prototype" || k === "constructor") throw new Refused("Invalid object key");
    out[k] = v && typeof v === "object" && !Array.isArray(v) ? merge(out[k] ?? {}, v) : structuredClone(v);
  }
  return out;
}

// agent/io.ts
var here = dirname(fileURLToPath(import.meta.url));
var appExe = process.env.SPEKTRALAB_AGENT_APP ?? [
  join(here, "..", process.platform === "win32" ? "spektralab.exe" : "spektralab"),
  ...process.platform === "linux" ? [join(process.env.APPDIR ?? "", "usr/bin/spektralab"), "/usr/bin/spektralab"] : []
].find((p) => existsSync(p)) ?? join(here, "..", "spektralab.exe");
var Child = class {
  process;
  next = 1;
  waiting = /* @__PURE__ */ new Map();
  constructor(executable, args) {
    this.process = spawn(executable, args, { stdio: ["pipe", "pipe", "pipe"], windowsHide: true });
    this.process.stderr.on("data", (b) => process.stderr.write(b));
    this.process.on("error", (e) => this.fail(e));
    this.process.on("exit", () => this.fail(new Error("SpektraLab service exited.")));
  }
  fail(e) {
    for (const w of this.waiting.values()) {
      clearTimeout(w.timer);
      w.reject(e);
    }
    this.waiting.clear();
  }
  receive(q, payload = Buffer.alloc(0)) {
    const w = this.waiting.get(q.id ?? -1);
    if (!w) return;
    this.waiting.delete(q.id ?? -1);
    clearTimeout(w.timer);
    if (q.ok === false) w.reject(Object.assign(new Error(typeof q.error === "string" ? q.error : (typeof q.error === "object" ? q.error.message : void 0) ?? "Service failed"), { code: typeof q.error === "object" ? q.error.code : void 0 }));
    else w.resolve({ result: q.result, payload });
  }
  send(method, params, binary, timeout = 3e5) {
    const id = this.next++, json = Buffer.from(JSON.stringify({ id, method, params }));
    return new Promise((resolve3, reject) => {
      const timer = setTimeout(() => {
        this.waiting.delete(id);
        this.process.kill();
        reject(new Error(`Timed out: ${method}`));
      }, timeout);
      this.waiting.set(id, { resolve: resolve3, reject, timer });
      if (binary) {
        const prefix = Buffer.alloc(8);
        prefix.writeUInt32LE(json.length);
        this.process.stdin.write(Buffer.concat([prefix, json]));
      } else this.process.stdin.write(json.toString() + "\n");
    });
  }
  stop() {
    this.process.stdin.end();
    setTimeout(() => this.process.kill(), 2e3).unref();
  }
};
var FileService = class extends Child {
  constructor() {
    super(appExe, ["--agent-files"]);
    createInterface({ input: this.process.stdout }).on("line", (line) => {
      try {
        this.receive(JSON.parse(line));
      } catch {
        this.fail(new Error("Invalid file-service response"));
      }
    });
  }
  async call(method, params = {}) {
    try {
      return (await this.send(method, params, false)).result;
    } catch (e) {
      throw new Refused(e.message);
    }
  }
};
var NativeHost = class extends Child {
  buffered = Buffer.alloc(0);
  constructor() {
    const dir = process.env.SPEKTRALAB_HOST_DIR ?? dirname(appExe);
    const executable = process.env.SPEKTRALAB_AGENT_HOST ?? join(dir, process.platform === "win32" ? "spektralab-host.exe" : "spektralab-host");
    const resources = process.env.SPEKTRALAB_AGENT_RESOURCES ?? [join(dir, "engine"), join(dir, "host", "engine"), join(here, "..", "host", "engine")].find((p) => existsSync(p));
    if (!resources) throw new Error("Engine resources are missing. Reinstall the complete application.");
    super(executable, ["--resources", resources]);
    this.process.stdout.on("data", (b) => {
      this.buffered = Buffer.concat([this.buffered, b]);
      while (this.buffered.length >= 8) {
        const h = this.buffered.readUInt32LE(0), p = this.buffered.readUInt32LE(4);
        if (h > 8 * 1024 * 1024 || p > 128 * 1024 * 1024) {
          this.fail(new Error("Oversized engine response"));
          this.process.kill();
          return;
        }
        if (this.buffered.length < 8 + h + p) return;
        try {
          this.receive(JSON.parse(this.buffered.subarray(8, 8 + h).toString()), this.buffered.subarray(8 + h, 8 + h + p));
        } catch (e) {
          this.fail(e);
        }
        this.buffered = this.buffered.subarray(8 + h + p);
      }
    });
  }
  request = (method, params = {}, opts) => this.send(method, params, true, opts?.timeoutMs ?? 3e5);
  async result(method, params = {}) {
    return (await this.request(method, params)).result;
  }
};
function absolute(path2) {
  return resolve(path2.startsWith("~/") ? join(process.env.USERPROFILE ?? process.env.HOME ?? "", path2.slice(2)) : path2);
}

// agent/platform.ts
import { mkdir, access, readFile } from "node:fs/promises";
var service;
function setFiles(s) {
  service = s;
}
var baseName = (p) => p.split(/[\\/]/).pop() ?? p;
var dirName = (p) => {
  const i = Math.max(p.lastIndexOf("/"), p.lastIndexOf("\\"));
  return i > 0 ? p.slice(0, i) : p;
};
var joinPath = (dir, name) => dir.replace(/[\\/]$/, "") + "/" + name;
var platform = () => ({
  sidecarLoad: (image) => service.call("sidecar_load", { path: image }),
  pairLoad: async (path2) => {
    const b = await readFile(path2);
    if (b.length > 1024 * 1024) throw new Refused("Pair document too large");
    return JSON.parse(b.toString());
  },
  ensureDir: async (path2) => {
    await mkdir(path2, { recursive: true });
  },
  pathExists: async (path2) => {
    try {
      await access(path2);
      return true;
    } catch {
      return false;
    }
  },
  log: (_level, message) => process.stderr.write(message + "\n")
});

// agent/host.ts
var connection;
function setHost(h) {
  connection = h;
}
var host = () => ({ transport: connection, probe: (path2) => connection.result("probe", { path: path2 }) });

// src/shared/stocks.ts
var StockCatalog = class {
  stocks;
  constructor(stocks) {
    this.stocks = stocks;
  }
  get films() {
    return this.stocks.filter((s) => s.stage === "filming");
  }
  get papers() {
    return this.stocks.filter((s) => s.stage === "printing");
  }
  stock(id) {
    return this.stocks.find((s) => s.id === id);
  }
  isPositive(id) {
    return this.stock(id)?.type === "positive";
  }
  isMonochrome(id) {
    return this.stock(id)?.monochrome === true;
  }
  canPrint(film, paper) {
    const f = this.stock(film), p = this.stock(paper);
    return !f || !p || !!f.monochrome === !!p.monochrome;
  }
  /** Still first, then cine, as the Mac picker orders them; then by polarity. */
  filmGroups() {
    const ordered = [...this.films.filter((s) => s.use !== "cine"), ...this.films.filter((s) => s.use === "cine")];
    const groups = [
      { title: "Positive", films: ordered.filter((s) => s.type === "positive") },
      { title: "Negative", films: ordered.filter((s) => s.type !== "positive" && !s.monochrome) }
    ];
    const mono = ordered.filter((s) => s.type !== "positive" && s.monochrome);
    if (mono.length) groups.push({ title: "Black & White", films: mono });
    return groups;
  }
  paperGroups() {
    return [
      { title: "Still", papers: this.papers.filter((s) => s.use !== "cine") },
      { title: "Cine", papers: this.papers.filter((s) => s.use === "cine") }
    ];
  }
  coverURL(id) {
    const c = this.stock(id)?.cover;
    return c ? `assets/FilmCovers/${c}` : null;
  }
};
var EMPTY_CATALOG = new StockCatalog([]);

// src/shared/pair.ts
var PLACEMENT_DEFAULT = { scale: 1, x: 0, y: 0, quarterTurns: 0 };
var PAIR_SIDES = ["left", "right"];
function isPairPath(path2) {
  return /\.spektrapair$/i.test(path2);
}
var pairSpacing = (p) => p.onStrip ? 1 : clamp(p.spacingMM, 0.5, 2);
var pairAspect = (p) => p.turned ? 4 / 3 : 3 / 4;
function newHole(path2) {
  return { path: path2, placement: { ...PLACEMENT_DEFAULT }, exposureEV: 0, decode: { ...DECODE_DEFAULT }, geometry: GEOMETRY_DEFAULT, autoExposure: true, printScope: "film", exposureScope: "frame" };
}
var obj3 = (v) => v && typeof v === "object" && !Array.isArray(v) ? v : {};
var num2 = (v, fallback, lo = -Infinity, hi = Infinity) => typeof v === "number" && Number.isFinite(v) ? clamp(v, lo, hi) : fallback;
function decodePair(raw) {
  const p = obj3(raw);
  if (typeof p.folder !== "string" || p.schemaVersion !== void 0 && p.schemaVersion !== 1) return null;
  function hole(raw2) {
    if (raw2 == null) return null;
    const h = obj3(raw2), pl = obj3(h.placement), pr = obj3(h.print);
    if (typeof h.path !== "string" || !h.path || isPairPath(h.path)) throw new Error("A half-frame hole must reference a photograph.");
    const out = {
      ...newHole(h.path),
      placement: { scale: num2(pl.scale, 1, 1, 4), x: num2(pl.x, 0, -1, 1), y: num2(pl.y, 0, -1, 1), quarterTurns: (Math.round(num2(pl.quarterTurns, 0)) % 4 + 4) % 4 },
      exposureEV: num2(h.exposureEV, 0, -5, 5),
      decode: decodeSidecar({ decode: h.decode }).decode,
      geometry: decodeGeometry(h.geometry),
      autoExposure: h.autoExposure !== false,
      printScope: h.printScope === "frame" ? "frame" : "film",
      exposureScope: h.exposureScope === "film" ? "film" : "frame"
    };
    if (typeof h.meteredEV === "number" && Number.isFinite(h.meteredEV)) out.meteredEV = h.meteredEV;
    if (typeof h.meteredFor === "string") out.meteredFor = h.meteredFor;
    if (typeof h.meterMethod === "string") out.meterMethod = h.meterMethod;
    if (h.adjustments) out.adjustments = decodeAdjustments(h.adjustments);
    if (h.print) out.print = { brightnessStops: num2(pr.brightnessStops, 0, -3, 3), yFilterShift: num2(pr.yFilterShift, 0, -1, 1), mFilterShift: num2(pr.mFilterShift, 0, -1, 1), preflashExposure: num2(pr.preflashExposure, 0, 0, 0.03) };
    return out;
  }
  try {
    return { schemaVersion: 1, folder: p.folder, left: hole(p.left), right: hole(p.right), spacingMM: num2(p.spacingMM, 1, 0.5, 2), onStrip: p.onStrip === true, turned: p.turned === true };
  } catch {
    return null;
  }
}
function pairLayout(across, spacingMM = 1, turned = false) {
  const a = Math.max(8, Math.floor(across)), along = Math.max(6, Math.round(a * 18 / 24));
  const advance = Math.round(along * (18 + spacingMM) / 18);
  const hole = turned ? { width: a, height: along } : { width: along, height: a };
  return {
    hole,
    advance,
    size: turned ? { width: hole.width, height: advance + hole.height } : { width: advance + hole.width, height: hole.height },
    rects: { left: { x: 0, y: 0, ...hole }, right: { x: turned ? 0 : advance, y: turned ? advance : 0, ...hole } }
  };
}
function pairRects(p, across = 2400) {
  const l = pairLayout(across, pairSpacing(p), p.turned);
  const rect = (r) => ({ x: r.x / l.size.width, y: r.y / l.size.height, width: r.width / l.size.width, height: r.height / l.size.height });
  return { left: rect(l.rects.left), right: rect(l.rects.right) };
}
function placementSourceRect(p, source, aspect = 0.75) {
  let w = source.width, h = source.height;
  if (w <= 0 || h <= 0) return { x: 0, y: 0, width: 0, height: 0 };
  if (w / h > aspect) w = h * aspect;
  else h = w / aspect;
  const scale = clamp(p.scale, 1, 4);
  w /= scale;
  h /= scale;
  const cx = source.width / 2 + clamp(p.x, -1, 1) * (source.width - w) / 2;
  const cy = source.height / 2 + clamp(p.y, -1, 1) * (source.height - h) / 2;
  return { x: cx - w / 2, y: cy - h / 2, width: w, height: h };
}
var placementTurnedSize = (p, size) => p.quarterTurns % 2 ? { width: size.height, height: size.width } : size;
function sourcePairLayout(p, sizes) {
  const across = [];
  let longest = 0;
  for (const side of PAIR_SIDES) {
    const h = p[side], size = sizes[side];
    if (!h || !size) continue;
    const framed = outputSize(h.geometry, size), turned = placementTurnedSize(h.placement, framed);
    const cut = placementSourceRect({ ...h.placement, scale: 1 }, turned, pairAspect(p));
    across.push(p.turned ? cut.width : cut.height);
    longest = Math.max(longest, framed.width, framed.height);
  }
  let a = across.length ? Math.min(...across) : 2400;
  if (longest > 0) a = Math.min(a, longest / (37 / 24));
  return pairLayout(a, pairSpacing(p), p.turned);
}
function pairSnapshotFor(pair, p) {
  return { ...structuredClone(pair), printEffects: p.printEffects };
}
function pairFitRegion(pair, right) {
  const r = pairRects(pair)[right ? "right" : "left"];
  return [r.x, r.y, r.x + r.width, r.y + r.height];
}
function pairFilmFormat(p, pair) {
  return clamp((36 + pairSpacing(pair)) * filmFormatMM(p.filmSide, p.sideLengthMM, 24 / 18, 1) / 24, 4, 200);
}
function resolvePairParams(p, pair, first, second, catalog) {
  if (p.filmFrame === FILM_PARAMS_DEFAULT.filmFrame && p.filmSide === FILM_PARAMS_DEFAULT.filmSide && p.sideLengthMM === FILM_PARAMS_DEFAULT.sideLengthMM)
    p = { ...p, filmFrame: FILM_FRAME_CUSTOM.id, filmSide: "long", sideLengthMM: 24 };
  const base = resolveFilmEdgeParams(p, GEOMETRY_DEFAULT, first, catalog);
  return {
    ...base,
    autoExposure: false,
    filmFormatMM: pairFilmFormat(p, pair),
    pairSplit: 0.5,
    filmEdge: { ...base.filmEdge, format: "135_half", pair: true },
    dateBack: {
      ...base.dateBack,
      camera: "135_half",
      frameScale: 1,
      framing: "",
      textB: p.dateBack.face === "data" ? shootingText(second) : captureDate(second?.datetime_original, p.dateBack.order)
    }
  };
}

// src/shared/latitude.ts
function latitudeRequest(s) {
  return {
    highlight_pull_back: s.highlightPullBack,
    shadow_pull_back: s.shadowPullBack,
    rolloff: s.rolloff,
    max_lift: s.maxLift,
    norm: s.norm,
    shadow_percentile: s.shadowPercentile,
    highlight_percentile: s.highlightPercentile
  };
}
function applyLatitudeFit(base, fit) {
  const d = fit?.params_delta;
  if (!fit?.valid || !d || typeof d.scene_latitude_active !== "boolean" || !["power", "y", "max"].includes(d.scene_latitude_norm)) return null;
  const out = {
    ...base,
    highlightPullBack: fit.highlight?.pull_back,
    shadowPullBack: fit.shadow?.pull_back,
    active: d.scene_latitude_active,
    norm: d.scene_latitude_norm,
    highlightKnee: d.scene_latitude_highlight_knee,
    highlightRoom: d.scene_latitude_highlight_room,
    shadowKnee: d.scene_latitude_shadow_knee,
    shadowRoom: d.scene_latitude_shadow_room,
    rolloff: d.scene_latitude_rolloff,
    maxLift: d.scene_latitude_max_lift
  };
  return [
    out.highlightPullBack,
    out.shadowPullBack,
    out.highlightKnee,
    out.highlightRoom,
    out.shadowKnee,
    out.shadowRoom,
    out.rolloff,
    out.maxLift
  ].every(Number.isFinite) ? out : null;
}

// src/export/recipes.ts
var NAME_TOKENS = ["originalName", "filmStock", "printStock", "date"];
var naming = () => ({ order: [...NAME_TOKENS], tokens: ["originalName", "filmStock", "printStock"], separator: "_" });
var DEFAULT_RECIPES = [
  { id: "jpeg-p3", name: "JPEG \u2014 Display P3", format: "jpeg", bitDepth: 8, colorSpace: "display-p3", quality: 92, longEdge: 0, folder: { kind: "besideOriginal" }, subfolder: "SpektraLab", existing: "addSuffix", naming: naming() },
  { id: "tiff-prophoto", name: "TIFF 16-bit \u2014 ProPhoto", format: "tiff", bitDepth: 16, colorSpace: "prophoto", quality: 100, longEdge: 0, folder: { kind: "besideOriginal" }, subfolder: "SpektraLab", existing: "addSuffix", naming: naming() },
  { id: "png-srgb", name: "PNG 8-bit \u2014 sRGB", format: "png", bitDepth: 8, colorSpace: "sRGB", quality: 100, longEdge: 0, folder: { kind: "besideOriginal" }, subfolder: "SpektraLab", existing: "addSuffix", naming: naming() },
  { id: "di", name: "Digital Intermediate", format: "di", bitDepth: 16, colorSpace: "display-p3", quality: 100, longEdge: 0, folder: { kind: "besideOriginal" }, subfolder: "_prints", existing: "addSuffix", naming: naming() }
];
var extensionOf = (r) => r.format === "jpeg" ? "jpg" : r.format === "png" ? "png" : "tif";
function hostFormat(r) {
  if (r.format === "jpeg") return "jpeg";
  if (r.format === "png") return "png";
  return r.bitDepth === 8 ? "tiff8" : "tiff16";
}
var pad = (n) => String(n).padStart(2, "0");
function stem(r, c) {
  const chosen = r.naming.order.filter((t) => r.naming.tokens.includes(t));
  const parts = chosen.map((t) => {
    switch (t) {
      case "originalName":
        return c.originalName;
      case "filmStock":
        return c.filmStock;
      case "printStock":
        return c.printStock;
      case "date":
        return `${c.date.getFullYear()}-${pad(c.date.getMonth() + 1)}-${pad(c.date.getDate())}`;
    }
  }).filter((s) => s.length > 0);
  const joined = parts.join(r.naming.separator);
  return (joined || c.originalName).replace(/[/\\:]/g, "-");
}
var stockToken = (name) => name.replace(/^(Kodak|Fujifilm|Fuji)\s+(Professional\s+)?/, "").replace(/\s+/g, "_");
async function resolveTarget(dir, base, ext, policy, exists, join3) {
  const first = join3(dir, `${base}.${ext}`);
  if (!await exists(first)) return { path: first, overwrite: false };
  if (policy === "overwrite") return { path: first, overwrite: true };
  if (policy === "skip") return null;
  for (let i = 2; i < 1e4; i++) {
    const p = join3(dir, `${base}-${i}.${ext}`);
    if (!await exists(p)) return { path: p, overwrite: false };
  }
  return null;
}
function decodeRecipes(raw) {
  if (!Array.isArray(raw)) return DEFAULT_RECIPES;
  const out = [];
  for (const r of raw) {
    if (!r || typeof r !== "object") continue;
    const o = r;
    const base = DEFAULT_RECIPES.find((d) => d.format === o.format) ?? DEFAULT_RECIPES[0];
    const n = o.naming;
    out.push({
      ...base,
      ...o,
      id: typeof o.id === "string" ? o.id : `r${out.length}`,
      ...o.tiffCompression !== void 0 ? { tiffCompression: o.tiffCompression === "lzw" ? "lzw" : "none" } : {},
      ...o.embedsPreview !== void 0 ? { embedsPreview: o.embedsPreview === true } : {},
      naming: {
        order: Array.isArray(n?.order) ? [...n.order.filter((t) => NAME_TOKENS.includes(t)), ...NAME_TOKENS.filter((t) => !n.order.includes(t))] : [...NAME_TOKENS],
        tokens: (() => {
          const on = Array.isArray(n?.tokens) ? n.tokens.filter((t) => NAME_TOKENS.includes(t)) : [];
          return on.length ? on : ["originalName"];
        })(),
        separator: typeof n?.separator === "string" ? n.separator : "_"
      }
    });
  }
  const recovered = [];
  for (let i = 0; i < out.length; i++) {
    const r = out[i];
    const builtin = DEFAULT_RECIPES.find((d) => d.id === r.id);
    if (builtin && JSON.stringify(r) !== JSON.stringify(builtin)) {
      recovered.push({ ...r, id: `custom-recovered-${i}`, name: `${r.name} (custom)` });
      out[i] = structuredClone(builtin);
    }
  }
  return out.length ? [...out, ...recovered] : DEFAULT_RECIPES;
}

// src/export/exporter.ts
function hostWrites(methods) {
  return !!methods?.includes("export_frame");
}
async function targetFor(r, f, catalog) {
  const dir0 = r.folder.kind === "fixed" ? r.folder.path : dirName(f.path);
  const dir = r.subfolder.trim() ? joinPath(dir0, r.subfolder.trim()) : dir0;
  const name = baseName(f.path).replace(/\.[^.]+$/, "");
  const date = f.dateTaken ? new Date(f.dateTaken) : /* @__PURE__ */ new Date();
  const base = stem(r, {
    originalName: name,
    filmStock: stockToken(catalog.stock(f.params.filmStock)?.name ?? f.params.filmStock),
    printStock: f.params.scanFilm ? "Scan" : stockToken(catalog.stock(f.params.printStock)?.name ?? f.params.printStock),
    date: Number.isFinite(date.getTime()) ? date : /* @__PURE__ */ new Date()
  });
  return { dir, base };
}
async function captureExportFrames(paths, selected, catalog, gate, recalculateEffectsAfterCrop, cancelled = () => false) {
  const current = selected ? structuredClone(selected) : null;
  const frozenGate = structuredClone(gate);
  const result = [];
  for (const path2 of [...paths]) {
    if (cancelled()) break;
    try {
      const active = path2 === current?.path ? current : null;
      const saved = active ? null : await platform().sidecarLoad(path2);
      const sidecar = active?.sidecar ?? structuredClone(saved == null ? newSidecar() : decodeSidecar(saved));
      if (isPairPath(path2)) {
        const pair = active?.pair ?? decodePair(await platform().pairLoad(path2));
        if (!pair) throw new Error("The half-frame pair recipe cannot be read.");
        const shots = {};
        for (const side of ["left", "right"]) {
          const hole = pair[side];
          if (!hole) throw new Error("Fill both half-frame holes before exporting.");
          const known = active?.pairInfo?.[side];
          shots[side] = known ?? { ...await host().probe(hole.path), available: true };
          if (!shots[side]?.available) throw new Error(shots[side]?.error ?? "A half-frame photograph cannot be read.");
        }
        const native2 = sourcePairLayout(pair, { left: shots.left, right: shots.right }).size;
        const params2 = resolvePairParams(
          normalizeStockPair(sidecar.params, catalog),
          pair,
          shots.left?.metadata ?? null,
          shots.right?.metadata ?? null,
          catalog
        );
        result.push({ path: path2, frame: structuredClone({
          path: path2,
          session: active?.session,
          params: params2,
          adjustments: sidecar.adjustments,
          geometry: canvasGeometryFor(params2, sidecar.geometry, frozenGate),
          sourceGeometry: sourceGeometryFor(params2, sidecar.geometry, frozenGate) ?? GEOMETRY_DEFAULT,
          decode: sidecar.decode,
          gate: frozenGate,
          native: native2,
          pair: pairSnapshotFor(pair, params2),
          dateTaken: shots.left?.metadata?.datetime_original ?? shots.right?.metadata?.datetime_original,
          scenePlacement: sidecar.placementNeedsFit ? { ...latitudeRequest(params2.sceneLatitude), region: pairFitRegion(pair, params2.placementIsRight) } : void 0,
          scenePlacementSide: sidecar.placementNeedsFit && params2.placementIsRight ? "right" : void 0
        }) });
        continue;
      }
      const info = active?.native && active.metadata !== void 0 ? null : await host().probe(path2);
      const native = active?.native ?? (info ? { width: info.width, height: info.height } : void 0);
      if (!native || native.width <= 0 || native.height <= 0) throw new Error("The photograph has no usable dimensions.");
      let params = { ...normalizeStockPair(sidecar.params, catalog) };
      const size = recalculateEffectsAfterCrop ? outputSize(sidecar.geometry, native) : native;
      const aspect = Math.max(size.width, size.height) / Math.max(1, Math.min(size.width, size.height));
      const crop = sidecar.geometry.crop;
      const cropScale = recalculateEffectsAfterCrop ? 1 / Math.max(crop.width, crop.height, 1e-3) : 1;
      params.filmFormatMM = filmFormatMM(params.filmSide, params.sideLengthMM, aspect, cropScale);
      params = resolveFilmEdgeParams(params, sidecar.geometry, active?.metadata ?? info?.metadata ?? null, catalog, native);
      result.push({ path: path2, frame: structuredClone({
        path: path2,
        session: active?.session,
        params,
        adjustments: sidecar.adjustments,
        geometry: canvasGeometryFor(params, sidecar.geometry, frozenGate),
        sourceGeometry: sourceGeometryFor(params, sidecar.geometry, frozenGate) ?? GEOMETRY_DEFAULT,
        decode: sidecar.decode,
        gate: frozenGate,
        native,
        dateTaken: active?.dateTaken ?? info?.metadata.datetime_original,
        scenePlacement: sidecar.placementNeedsFit ? latitudeRequest(params.placementIsRight ? params.sceneLatitudeOther : params.sceneLatitude) : void 0
      }) });
    } catch (e) {
      result.push({ path: path2, error: e instanceof Error ? e.message : String(e) });
    }
  }
  return result;
}
var exportSerial = 0;
async function exportFrame(recipe, frame, catalog, methods, control = {}) {
  const r = structuredClone(recipe);
  const f = structuredClone(frame);
  const started = performance.now();
  const cancelled = () => control.cancelled?.() ?? false;
  try {
    if (cancelled()) return { kind: "cancelled" };
    if (f.pair && !methods?.includes("open_pair")) throw new Error("This engine cannot export half-frame pairs. Update the engine.");
    if ((r.format === "tiff" || r.format === "di") && (r.tiffCompression === "lzw" && !control.tiffOptions?.includes("lzw") || r.format === "tiff" && r.embedsPreview && !control.tiffOptions?.includes("preview-page")))
      throw new Error("This engine does not support the selected TIFF compression or preview page. Update the engine.");
    if (r.format === "di") {
      if (!methods?.includes("export_cineon") || !f.gate.digitalIntermediate)
        throw new Error("This engine cannot export Cineon Digital Intermediate files.");
    } else if (!hostWrites(methods)) {
      throw new Error("This engine does not support complete frame export (export_frame). Update the engine before exporting.");
    }
    const { dir, base } = await targetFor(r, f, catalog);
    await platform().ensureDir(dir);
    const target = await resolveTarget(dir, base, extensionOf(r), r.existing, (p) => platform().pathExists(p), joinPath);
    if (cancelled()) return { kind: "cancelled" };
    if (!target) return { kind: "skipped", path: joinPath(dir, `${base}.${extensionOf(r)}`) };
    const params = fullDelta(f.params, f.gate, catalog);
    const decode = decodeWire(f.decode, isRawPath(f.path));
    const job = { session: f.session ?? "", progressId: `export-${Date.now()}-${++exportSerial}` };
    control.active?.(job);
    const res = await host().transport.request(r.format === "di" ? "export_cineon" : "export_frame", {
      session: f.session,
      source_path: f.path,
      params,
      decode: decode ?? void 0,
      adjustments: f.adjustments,
      geometry: f.geometry,
      source_geometry: f.sourceGeometry ?? GEOMETRY_DEFAULT,
      pair: f.pair,
      scene_placement: f.scenePlacement,
      scene_placement_side: f.scenePlacementSide,
      path: target.path,
      format: hostFormat(r),
      quality: r.format === "jpeg" ? r.quality : void 0,
      tiff_compression: r.format === "tiff" || r.format === "di" ? r.tiffCompression ?? "none" : void 0,
      embed_preview: r.format === "tiff" ? r.embedsPreview ?? false : void 0,
      color_space: r.colorSpace,
      long_edge: r.format === "di" ? 0 : r.longEdge,
      overwrite: target.overwrite,
      progress_id: job.progressId
    }, { timeoutMs: 18e5 });
    if (res.payload.byteLength) throw new Error("export_frame unexpectedly returned image data.");
    const { path: path2, width, height, timings_ms } = res.result;
    if (typeof path2 !== "string" || typeof width !== "number" || typeof height !== "number" || width <= 0 || height <= 0)
      throw new Error("The engine returned invalid export dimensions.");
    platform().log("info", `export (${hostFormat(r)}, ${width}x${height}) host ms: ${JSON.stringify(timings_ms ?? {})} \xB7 TOTAL ${Math.round(performance.now() - started)}`);
    return { kind: "written", path: path2, width, height, carriesEdits: r.format !== "di" };
  } catch (e) {
    if (cancelled() && e.code === "cancelled") return { kind: "cancelled" };
    return { kind: "failed", message: e instanceof Error ? e.message : String(e) };
  } finally {
    control.active?.(null);
  }
}

// src/shared/renderPreferences.ts
var RENDER_PREFERENCES_DEFAULT = {
  recalculateEffectsAfterCrop: false,
  diBlueCompensation: false
};
function renderPreferences(value) {
  if (!value || typeof value !== "object") throw new Error("Invalid saved rendering preferences");
  const v = value;
  if (typeof v.recalculateEffectsAfterCrop !== "boolean" || typeof v.diBlueCompensation !== "boolean")
    throw new Error("Invalid saved rendering preferences");
  return { recalculateEffectsAfterCrop: v.recalculateEffectsAfterCrop, diBlueCompensation: v.diBlueCompensation };
}

// agent/workspace.ts
var Workspace = class {
  files = new FileService();
  engine = null;
  catalog = null;
  hello;
  gate;
  path = "";
  sid = "";
  sidecar;
  pair = null;
  info;
  opened;
  frame;
  decodeKey = "";
  sourceStamp = "";
  rendering = { ...RENDER_PREFERENCES_DEFAULT };
  constructor() {
    setFiles(this.files);
  }
  async status() {
    return this.files.call("status");
  }
  async start() {
    if (!this.catalog) {
      const file = process.env.SPEKTRALAB_AGENT_CATALOG ?? join2(here, "StockCatalog.json");
      this.catalog = new StockCatalog(JSON.parse(await readFile2(file, "utf8")).stocks);
    }
    if (!this.engine) {
      this.engine = new NativeHost();
      setHost(this.engine);
      this.hello = await this.engine.result("hello");
      this.gate = featureGate(this.hello.capabilities?.backend?.unsupported_features);
    }
  }
  async load(path2) {
    await this.start();
    path2 = absolute(path2);
    this.sidecar = decodeSidecar(await this.files.call("sidecar_load", { path: path2 }));
    this.pair = isPairPath(path2) ? decodePair(JSON.parse(await readFile2(path2, "utf8"))) : null;
    if (isPairPath(path2) && !this.pair) throw new Refused("Invalid half-frame pair document");
    this.info = await this.engine.result("probe", { path: path2 });
    const md = await stat(path2), stamp = JSON.stringify([md.size, md.mtimeMs]);
    if ((this.path !== path2 || this.sourceStamp !== stamp) && this.sid) {
      await this.engine.result("close", { session: this.sid });
      this.sid = "";
    }
    this.sourceStamp = stamp;
    this.path = path2;
  }
  async prepare() {
    const [item] = await captureExportFrames([this.path], {
      path: this.path,
      sidecar: this.sidecar,
      session: this.sid || void 0,
      native: { width: this.info.width, height: this.info.height },
      metadata: this.info.metadata,
      pair: this.pair,
      pairInfo: this.info.pair_info
    }, this.catalog, this.gate, this.rendering.recalculateEffectsAfterCrop);
    if (!item || "error" in item) throw new Refused(item && "error" in item ? item.error : "Cannot prepare frame");
    this.frame = item.frame;
    this.sidecar.params = structuredClone(this.frame.params);
  }
  async develop() {
    await this.prepare();
    const params = fullDelta(this.frame.params, this.gate, this.catalog);
    const decode = decodeWire(this.sidecar.decode, isRawPath(this.path));
    const key = JSON.stringify(decode);
    if (!this.sid) {
      this.opened = await this.engine.result(this.pair ? "open_pair" : "open", { path: this.path, params, pair: this.frame.pair, decode: decode ?? void 0 });
      this.sid = this.opened.session;
    } else if (this.pair) this.opened = await this.engine.result("update_pair", { session: this.sid, params, pair: this.frame.pair });
    else if (key !== this.decodeKey) this.opened = await this.engine.result("redecode", { session: this.sid, decode: decode ?? void 0 });
    this.decodeKey = key;
    this.frame.session = this.sid;
    await this.engine.result("render_view", {
      session: this.sid,
      params,
      adjustments: this.frame.adjustments,
      geometry: this.frame.geometry,
      source_geometry: this.frame.sourceGeometry,
      tier: "preview",
      display: "srgb",
      long_edge: 64,
      generation: 1
    });
  }
  async save() {
    await this.files.call("sidecar_save", { path: this.path, value: encodeSidecar(this.sidecar) });
  }
  async edit(patch) {
    const leaves = validate(patch, this.catalog);
    const has = (prefix) => leaves.some((k) => k === prefix || k.startsWith(prefix + "."));
    const want = merge(document(this.sidecar), patch), p = want.params;
    if (this.catalog.isPositive(p.filmStock) && (has("params.printStock") || has("params.scanFilm") && !p.scanFilm)) throw new Refused("Slide films are scanned and take no paper.");
    if (has("params.printStock") && !this.catalog.canPrint(p.filmStock, p.printStock)) throw new Refused("Film and paper emulsion types must match.");
    for (const [active, supported, label] of [[p.filmEdge.active, this.gate.overscan, "Film Edge"], [p.dateBack.active, this.gate.dateImprint, "Date Back"], [p.digitalIntermediate, this.gate.digitalIntermediate, "Digital Intermediate"]])
      if (active && !supported) throw new Refused(`${label} is unavailable in this engine.`);
    if (has("decode") && !isRawPath(this.path)) throw new Refused("Decode edits need a RAW photograph; pair-hole decode edits use the app.");
    if (has("geometry.crop") && (want.geometry.crop.width <= 0.01 || want.geometry.crop.height <= 0.01)) throw new Refused("Crop must exceed1% on both sides.");
    if (has("params.filmStock")) {
      p.scanFilm = this.catalog.isPositive(p.filmStock);
      if (!has("params.printStock")) p.printStock = this.catalog.stock(p.filmStock)?.targetPrint ?? p.printStock;
    }
    if (has("params.filmFrame") || has("params.filmSide")) {
      const f = filmFrameNamed(p.filmFrame);
      if (f.id !== "Custom") p.sideLengthMM = p.filmSide === "short" ? f.short : f.long;
    }
    if (has("params.sideLengthMM")) p.filmFrame = "Custom";
    if ((has("decode.temperature") || has("decode.tint")) && !has("decode.whiteBalance")) want.decode.whiteBalance = "Custom";
    else if (has("decode.whiteBalance") && !has("decode.temperature")) {
      const k = WB_KELVIN[want.decode.whiteBalance];
      if (k) want.decode.temperature = k;
    }
    want.params = normalizeStockPair(p, this.catalog);
    if (has("geometry")) {
      if (has("geometry.crop")) want.geometry.intendedSize = { width: want.geometry.crop.width, height: want.geometry.crop.height };
      want.geometry = fitted(want.geometry, this.info);
    }
    if (edgeEffective(want.params.filmEdge, this.gate)) want.geometry = gateFramed(want.geometry, want.params.filmEdge, this.info);
    this.sidecar = { ...this.sidecar, ...want, state: "stale" };
    await this.develop();
    await this.save();
    return { written: leaves, edit: document(this.sidecar) };
  }
  async preview(output, longEdge = 1024) {
    await this.develop();
    const temporary = output ? void 0 : await mkdtemp(join2(tmpdir(), "spektralab-agent-"));
    const path2 = output ? absolute(output) : join2(temporary, "preview.jpg");
    if (resolve2(path2).toLowerCase() === resolve2(this.path).toLowerCase()) throw new Refused("The source photograph cannot be overwritten.");
    await this.engine.result("export_frame", {
      session: this.sid,
      source_path: this.path,
      pair: this.frame.pair,
      params: fullDelta(this.frame.params, this.gate, this.catalog),
      adjustments: this.frame.adjustments,
      geometry: this.frame.geometry,
      source_geometry: this.frame.sourceGeometry,
      path: path2,
      format: "jpeg",
      quality: 92,
      color_space: "srgb",
      long_edge: longEdge,
      overwrite: false
    });
    return { body: { preview: path2 }, preview: path2, temporary };
  }
  async call(name, args) {
    await this.files.call("begin");
    try {
      this.rendering = renderPreferences(await this.files.call("rendering"));
      await this.start();
      this.gate = featureGate(this.hello.capabilities?.backend?.unsupported_features, this.rendering.diBlueCompensation);
      if (name === "get_schema") return { body: { version: 1, sections: ["params", "adjustments", "geometry", "decode"], fields: fields(this.catalog) } };
      if (name === "list_stocks") return { body: { films: this.catalog.films, papers: this.catalog.papers } };
      if (name === "list_recipes") return { body: { recipes: decodeRecipes(await this.files.call("recipes")) } };
      if (name === "edit_image") validate(args.patch, this.catalog);
      await this.load(args.path);
      let body;
      if (name === "describe_image") return { body: { path: this.path, ...this.info, state: this.sidecar.state, film: this.sidecar.params.filmStock, paper: this.sidecar.params.scanFilm ? null : this.sidecar.params.printStock } };
      if (name === "get_edit") return { body: document(this.sidecar) };
      if (name === "edit_image") body = await this.edit(args.patch);
      else if (name === "reset_edit") {
        const defaults = structuredClone(newSidecar());
        this.sidecar = { ...this.sidecar, params: defaults.params, adjustments: defaults.adjustments, geometry: defaults.geometry, placementNeedsFit: false, state: "unprocessed" };
        await this.develop();
        await this.save();
        body = { edit: document(this.sidecar) };
      } else if (name === "process_image") {
        await this.develop();
        const solved = await this.engine.result("solve", { session: this.sid, target: "both" });
        this.sidecar.params.yFilterShift = 0;
        this.sidecar.params.mFilterShift = 0;
        this.sidecar.state = "processed";
        if (typeof solved.solved_params?.exposure_compensation_ev === "number") this.sidecar.solvedEV = solved.solved_params.exposure_compensation_ev;
        await this.develop();
        await this.save();
        body = { info: this.info, state: this.sidecar.state };
      } else if (name === "measure_latitude" || name === "place_scene") {
        await this.develop();
        const settings = structuredClone(this.sidecar.params.sceneLatitude);
        if (name === "place_scene") {
          settings.highlightPullBack = args.highlight;
          settings.shadowPullBack = args.shadow;
        }
        const request = { ...latitudeRequest(settings), ...this.pair ? { region: pairFitRegion(this.pair, this.sidecar.params.placementIsRight) } : {} };
        const result = await this.engine.result("scene_latitude", { session: this.sid, request });
        if (name === "measure_latitude") return { body: result };
        const placed = applyLatitudeFit(settings, result.fit);
        if (!placed) throw new Refused("Scene Placement fit refused: " + JSON.stringify(result.fit.issues));
        this.sidecar.params.sceneLatitude = placed;
        this.sidecar.placementNeedsFit = false;
        await this.develop();
        await this.save();
        body = result;
      } else if (name === "preview_image") return await this.preview(args.output, args.long_edge ?? 1024);
      else if (name === "export_image") {
        await this.develop();
        const recipes = decodeRecipes(await this.files.call("recipes"));
        const selected = args.recipe ? recipes.find((r) => r.name === args.recipe) : recipes[0];
        if (!selected) throw new Refused("No export recipe with that name");
        const recipe = structuredClone(selected);
        if (args.folder) {
          recipe.folder = { kind: "fixed", path: absolute(args.folder) };
          recipe.subfolder = "";
        }
        const written = await exportFrame(recipe, this.frame, this.catalog, this.hello.methods, { tiffOptions: this.hello.tiff_options });
        if (written.kind === "failed") throw new Error(written.message);
        return { body: { files: written.kind === "written" ? [written.path] : [], outcome: written } };
      } else throw new Refused("Unknown tool: " + name);
      if (args.preview !== false) {
        const p = await this.preview();
        return { ...p, body };
      }
      return { body };
    } finally {
      await this.files.call("end");
    }
  }
  async stop() {
    if (this.engine) {
      try {
        await this.engine.result("shutdown");
      } catch {
      }
      this.engine.stop();
    }
    this.files.stop();
  }
};
async function removeTemporary(result) {
  if (result.temporary) await rm(result.temporary, { recursive: true, force: true });
}

// agent/tools.ts
var path = { type: "string", description: "Absolute path of an existing photograph or half-frame pair." };
var preview = { type: "boolean", description: "Return a small preview (default true)." };
var tools = [
  ["get_schema", "schema", "Every editable field, range and read-only rule.", {}, []],
  ["list_stocks", "stocks", "Film and paper stock IDs.", {}, []],
  ["list_recipes", "recipes", "Saved export recipes.", {}, []],
  ["describe_image", "info", "Image dimensions, metadata and processing state.", { path }, ["path"]],
  ["get_edit", "get", "The four edit sections used by the application.", { path }, ["path"]],
  ["edit_image", "edit", "Strict JSON merge patch. Invalid fields are refused without writing. Originals are preserved.", { path, patch: { type: "object" }, preview }, ["path", "patch"]],
  ["reset_edit", "reset", "Reset film, print, grade and geometry; preserve decode.", { path, preview }, ["path"]],
  ["process_image", "process", "Develop, meter and solve the print filter pack; clear Y/M offsets.", { path, preview }, ["path"]],
  ["measure_latitude", "latitude", "Measure the scene and medium latitude and suggested pull-backs.", { path }, ["path"]],
  ["place_scene", "place", "Apply Scene Placement only if the engine Fit accepts it.", { path, highlight: { type: "number", minimum: 0, maximum: 6 }, shadow: { type: "number", minimum: 0, maximum: 6 }, preview }, ["path", "highlight", "shadow"]],
  ["preview_image", "preview", "Render a small finished sRGB JPEG.", { path, output: { type: "string" }, long_edge: { type: "integer", minimum: 64, maximum: 4096 } }, ["path"]],
  ["export_image", "export", "Write with a named saved recipe. Export only when requested.", { path, recipe: { type: "string" }, folder: { type: "string" } }, ["path"]]
].map(([name, command, description, properties, required]) => ({
  name,
  command,
  description,
  inputSchema: { type: "object", properties, required, additionalProperties: false }
}));
function checkTool(name, args) {
  const tool = tools.find((t) => t.name === name);
  if (!tool) throw new Refused("Unknown tool: " + name);
  if (!args || typeof args !== "object" || Array.isArray(args)) throw new Refused("Arguments must be an object.");
  const a = args;
  for (const key of tool.inputSchema.required) if (!(key in a)) throw new Refused(`${name} needs ${key}.`);
  for (const [key, value] of Object.entries(a)) {
    const p = tool.inputSchema.properties[key];
    if (!p) throw new Refused(`Unknown argument: ${key}`);
    if (p.type === "object" ? !value || typeof value !== "object" || Array.isArray(value) : p.type === "integer" ? !Number.isInteger(value) : typeof value !== p.type) throw new Refused(`Invalid ${key}: expected ${p.type}.`);
    if (typeof value === "number" && (!Number.isFinite(value) || p.minimum !== void 0 && value < p.minimum || p.maximum !== void 0 && value > p.maximum)) throw new Refused(`Invalid range for ${key}.`);
    if (typeof value === "string" && (!value || value.includes("\0"))) throw new Refused(`Invalid ${key}.`);
  }
  return a;
}
var instructions = "SpektraLab develops film and prints onto paper. Read describe_image and get_schema, process_image once, then use small physical edits and inspect previews. Scene Placement must pass place_scene. Nothing overwrites an original. Export only when requested. Agent access is controlled by Settings > Agents; turning it off refuses the next call.";
var editPrompt = { name: "edit_photo", title: "Edit a photo from one sentence", description: "Edit a photograph with film, paper and physical controls.", arguments: [{ name: "path", description: "Image path", required: true }, { name: "instruction", description: "Desired look", required: true }] };
async function mcp(input, call, image) {
  const message = input;
  if (!message || typeof message !== "object" || Array.isArray(message)) return { jsonrpc: "2.0", id: null, error: { code: -32600, message: "Invalid Request" } };
  if (!("id" in message)) return null;
  const result = (r) => ({ jsonrpc: "2.0", id: message.id, result: r });
  const error = (code, text) => ({ jsonrpc: "2.0", id: message.id, error: { code, message: text } });
  if (message.jsonrpc !== "2.0" || typeof message.method !== "string") return error(-32600, "Invalid Request");
  const p = message.params ?? {};
  switch (message.method) {
    case "initialize":
      return result({ protocolVersion: "2025-06-18", capabilities: { tools: {}, prompts: {} }, serverInfo: { name: "spektralab", title: "SpektraLab", version: "1.3.3" }, instructions });
    case "ping":
      return result({});
    case "tools/list":
      return result({ tools: tools.map(({ command: _command, ...t }) => t) });
    case "tools/call":
      if (typeof p.name !== "string") return error(-32602, "tools/call needs a name");
      try {
        const a = checkTool(p.name, p.arguments ?? {});
        const r = await call(p.name, a);
        return result({ content: await image(r), isError: false });
      } catch (e) {
        return result({ content: [{ type: "text", text: (e instanceof Refused ? "Refused: " : "Failed: ") + e.message }], isError: true });
      }
    case "prompts/list":
      return result({ prompts: [editPrompt] });
    case "prompts/get": {
      if (p.name !== "edit_photo") return error(-32602, "No such prompt");
      const a = p.arguments ?? {};
      return result({ description: editPrompt.description, messages: [{ role: "user", content: { type: "text", text: `Edit ${a.path ?? "<path>"} to match: ${a.instruction ?? ""}. Read describe_image, get_schema and process_image. Prefer film, paper, exposure and Scene Placement; inspect each preview before refining.` } }] });
    }
    default:
      return error(-32601, "Method not found");
  }
}

// agent/cli.ts
import { readFile as readFile3 } from "node:fs/promises";
async function parse(argv, stdin = async () => {
  let s = "";
  for await (const b of process.stdin) {
    s += b;
    if (s.length > 1024 * 1024) throw new Refused("Patch exceeds1MiB");
  }
  return s;
}) {
  const [command, ...rest] = argv, tool = tools.find((t) => t.command === command);
  if (!tool) throw new Refused("Unknown command. Use help.");
  const args = {};
  let previewOut;
  if ("path" in tool.inputSchema.properties) {
    const file = rest.shift();
    if (!file || file.startsWith("-")) throw new Refused("A photograph path is required");
    args.path = absolute(file);
  }
  while (rest.length) {
    const flag = rest.shift(), v = rest.shift();
    if (v === void 0) throw new Refused(flag + " requires a value");
    if (flag === "--patch" && tool.name === "edit_image") {
      const text = v === "-" ? await stdin() : v.startsWith("@") ? await readFile3(absolute(v.slice(1)), "utf8") : v;
      if (text.length > 1024 * 1024) throw new Refused("Patch exceeds1MiB");
      try {
        args.patch = JSON.parse(text);
      } catch {
        throw new Refused("Patch is not valid JSON");
      }
    } else if (flag === "--preview" && "preview" in tool.inputSchema.properties) {
      previewOut = absolute(v);
      args.preview = true;
    } else if ((flag === "-o" || flag === "--output") && tool.name === "preview_image") args.output = absolute(v);
    else if (flag === "--long-edge" && tool.name === "preview_image") args.long_edge = Number(v);
    else if ((flag === "--highlight" || flag === "--shadow") && tool.name === "place_scene") args[flag.slice(2)] = Number(v);
    else if (flag === "--recipe" && tool.name === "export_image") args.recipe = v;
    else if (flag === "--to" && tool.name === "export_image") args.folder = absolute(v);
    else throw new Refused("Unknown option: " + flag);
  }
  if ("preview" in tool.inputSchema.properties && args.preview === void 0) args.preview = false;
  if (tool.name === "preview_image" && !args.output) throw new Refused("preview needs -o OUT.jpg");
  return { name: tool.name, args: checkTool(tool.name, args), previewOut };
}

// agent/main.ts
var usage = `SpektraLab CLI: status | schema | stocks | recipes | info|get|reset|process|latitude FILE
edit FILE --patch JSON|@FILE|- [--preview OUT.jpg]
place FILE --highlight STOPS --shadow STOPS [--preview OUT.jpg]
preview FILE -o OUT.jpg [--long-edge N]
export FILE [--recipe NAME] [--to DIRECTORY]
mcp  (newline JSON-RPC over stdio)
Enable Settings > Agents first. Source photographs are never overwritten.
`;
async function main() {
  const argv = process.argv.slice(2), command = argv[0];
  if (!command || ["help", "--help", "-h"].includes(command)) {
    process.stdout.write(usage);
    return;
  }
  let ws;
  try {
    if (command === "mcp") {
      ws = new Workspace();
      const lines = createInterface2({ input: process.stdin, crlfDelay: Infinity });
      for await (const line of lines) {
        if (!line.trim()) continue;
        let response;
        if (line.length > 2 * 1024 * 1024) {
          response = { jsonrpc: "2.0", id: null, error: { code: -32600, message: "Request exceeds2MiB" } };
        } else try {
          const message = JSON.parse(line);
          response = await mcp(message, (name, args) => ws.call(name, args), async (r2) => {
            try {
              const content = [{ type: "text", text: JSON.stringify(r2.body) }];
              if (r2.preview) {
                const b = await readFile4(r2.preview);
                if (b.length > 32 * 1024 * 1024) throw new Error("Preview exceeds32MiB");
                content.push({ type: "image", mimeType: "image/jpeg", data: b.toString("base64") });
              }
              return content;
            } finally {
              await removeTemporary(r2);
            }
          });
        } catch {
          response = { jsonrpc: "2.0", id: null, error: { code: -32700, message: "Parse error" } };
        }
        if (response) process.stdout.write(JSON.stringify(response) + "\n");
      }
      return;
    }
    const parsed = command === "status" ? null : await parse(argv);
    ws = new Workspace();
    if (!parsed) {
      process.stdout.write(JSON.stringify({ ok: true, ...await ws.status() }) + "\n");
      return;
    }
    const r = await ws.call(parsed.name, parsed.args);
    try {
      const body = r.body && typeof r.body === "object" ? r.body : { result: r.body };
      if (parsed.previewOut && r.preview) {
        await copyFile(r.preview, parsed.previewOut, constants.COPYFILE_EXCL);
        body.preview = parsed.previewOut;
      }
      process.stdout.write(JSON.stringify({ ok: true, ...body }) + "\n");
    } finally {
      await removeTemporary(r);
    }
  } catch (e) {
    process.stdout.write(JSON.stringify({ ok: false, refused: e instanceof Refused, error: e.message }) + "\n");
    process.exitCode = e instanceof Refused ? 2 : 1;
  } finally {
    if (ws) await ws.stop();
  }
}
void main();
