# -*- coding: utf-8 -*-
"""生成软件图标：以 Portra 400 照片为底，叠加极简胶片框简笔 logo。"""
import os
from PIL import Image, ImageDraw, ImageFilter

SRC = r"C:\Users\ROG\.workbuddy\blobs\40\40df38cd82b796899ff34d9d729be02b3fad3db1d1907d913ebd51557dfa916b.jpg"
OUT_DIR = os.path.dirname(os.path.abspath(__file__))

TARGETS = {
    "icon.png": 512,
    "32x32.png": 32,
    "64x64.png": 64,
    "128x128.png": 128,
    "128x128@2x.png": 256,
    "Square30x30Logo.png": 30,
    "Square44x44Logo.png": 44,
    "Square71x71Logo.png": 71,
    "Square89x89Logo.png": 89,
    "Square107x107Logo.png": 107,
    "Square142x142Logo.png": 142,
    "Square150x150Logo.png": 150,
    "Square284x284Logo.png": 284,
    "Square310x310Logo.png": 310,
    "StoreLogo.png": 50,
}

def make_base(size):
    """照片底：中心正方形裁切 + 缩放 + 圆角。"""
    img = Image.open(SRC).convert("RGB")
    w, h = img.size
    side = min(w, h)
    left = (w - side) // 2
    top = (h - side) // 2
    img = img.crop((left, top, left + side, top + side))
    img = img.resize((size, size), Image.LANCZOS)
    return img

def draw_film_logo(img, size):
    """在图上叠加极简胶片框 logo（中心偏下）。"""
    img = img.convert("RGBA")
    overlay = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(overlay)

    # 胶片框：圆角矩形 + 上下两排齿孔
    bw = int(size * 0.56)          # 胶片框宽
    bh = int(size * 0.30)          # 胶片框高
    bx = (size - bw) // 2
    by = int(size * 0.52)          # 偏下，避开上部天空留白
    r = int(size * 0.035)

    # 半透明深色底框，提升文字/图形可读性
    d.rounded_rectangle([bx, by, bx + bw, by + bh], radius=r,
                        fill=(20, 16, 14, 200))
    # 框描边
    d.rounded_rectangle([bx, by, bx + bw, by + bh], radius=r,
                        outline=(255, 246, 226, 255), width=max(2, size // 64))

    # 上下齿孔
    n_holes = max(4, bw // (size // 10))
    hole_w = bw * 0.06
    hole_h = size * 0.028
    gap = (bw - n_holes * hole_w) / (n_holes + 1)
    for i in range(n_holes):
        hx = bx + gap + i * (hole_w + gap)
        # 上排齿孔
        d.rectangle([hx, by - hole_h * 0.4, hx + hole_w, by + hole_h * 0.6],
                    fill=(20, 16, 14, 255))
        # 下排齿孔
        d.rectangle([hx, by + bh - hole_h * 0.6, hx + hole_w, by + bh + hole_h * 0.4],
                    fill=(20, 16, 14, 255))

    # 中间画幅：横向小画面
    frame_w = int(bw * 0.72)
    frame_h = int(bh * 0.48)
    fx = (size - frame_w) // 2
    fy = by + (bh - frame_h) // 2
    d.rectangle([fx, fy, fx + frame_w, fy + frame_h],
                outline=(255, 246, 226, 255), width=max(2, size // 64))
    # 画幅内画一个"山/湖"极简剪影
    cx = fx + frame_w // 2
    d.polygon([(fx + frame_w * 0.15, fy + frame_h * 0.85),
               (fx + frame_w * 0.35, fy + frame_h * 0.40),
               (fx + frame_w * 0.55, fy + frame_h * 0.70),
               (fx + frame_w * 0.85, fy + frame_h * 0.85)],
              fill=(255, 246, 226, 255))

    img = Image.alpha_composite(img, overlay)
    return img

def make_icon(size, rounded=True):
    img = make_base(size)
    img = draw_film_logo(img, size)
    if rounded:
        radius = int(size * 0.18)
        mask = Image.new("L", (size, size), 0)
        d = ImageDraw.Draw(mask)
        d.rounded_rectangle([0, 0, size - 1, size - 1], radius=radius, fill=255)
        img.putalpha(mask)
    return img

def main():
    for fname, size in TARGETS.items():
        img = make_icon(size, rounded=(size >= 64))
        img.save(os.path.join(OUT_DIR, fname))
        print("saved", fname, size)

    ico = make_icon(256, rounded=False)
    ico.save(os.path.join(OUT_DIR, "icon.ico"), format="ICO",
             sizes=[(16, 16), (24, 24), (32, 32), (48, 48),
                    (64, 64), (128, 128), (256, 256)])
    print("saved icon.ico")

if __name__ == "__main__":
    main()
