# -*- coding: utf-8 -*-
"""用 lief 直接替换 exe 图标资源（绕过 windres 缺失）。

原理：遍历 PE 资源树，替换 RT_ICON 各尺寸的 PNG 位图数据，
并同步更新 RT_GROUP_ICON 目录条目里的 dwBytesInRes 字段。
"""
import lief
import struct
import os
import shutil

HERE = os.path.dirname(os.path.abspath(__file__))
EXE = os.path.join(HERE, "target/x86_64-pc-windows-gnu/release/spektralab.exe")
ICON_DIR = os.path.join(HERE, "icons")

# nID -> (尺寸, PNG 文件)
SIZE_BY_ID = {
    1: (16, "_icon_16.png"),
    2: (24, "_icon_24.png"),
    3: (32, "_icon_32.png"),
    4: (48, "_icon_48.png"),
    5: (64, "_icon_64.png"),
    6: (128, "_icon_128.png"),
    7: (256, "_icon_256.png"),
}

def find_type_dir(root, type_id):
    for c in root.childs:
        if c.id == type_id:
            return c
    return None

def main():
    # 备份
    bak = EXE + ".bak2"
    shutil.copy2(EXE, bak)

    exe = lief.PE.parse(EXE)
    root = exe.resources

    # 1. 替换 RT_ICON 数据
    icon_dir = find_type_dir(root, 3)  # ICON
    assert icon_dir is not None, "未找到 ICON 资源目录"

    new_sizes = {}  # nID -> 新 PNG 字节数
    for icon_node in icon_dir.childs:
        nid = icon_node.id
        if nid not in SIZE_BY_ID:
            continue
        size, png_name = SIZE_BY_ID[nid]
        png_path = os.path.join(ICON_DIR, png_name)
        png_data = open(png_path, "rb").read()
        # 找到 data 节点（lang=1033）
        for data_node in icon_node.childs:
            if data_node.is_data:
                data_node.content = png_data
                new_sizes[nid] = len(png_data)
                print(f"  RT_ICON nID={nid} ({size}x{size}): {len(png_data)} bytes")

    # 2. 更新 RT_GROUP_ICON 目录条目
    group_dir = find_type_dir(root, 14)  # GROUP_ICON
    assert group_dir is not None, "未找到 GROUP_ICON 资源目录"
    for group_node in group_dir.childs:
        for data_node in group_node.childs:
            if data_node.is_data:
                content = bytearray(data_node.content)
                # 解析 header
                reserved, typ, count = struct.unpack('<HHH', bytes(content[:6]))
                for i in range(count):
                    off = 6 + i * 14
                    bWidth, bHeight, bColorCount, bReserved, wPlanes, wBitCount, dwBytesInRes, nID = \
                        struct.unpack('<BBBBHHIH', bytes(content[off:off+14]))
                    if nID in new_sizes:
                        # 更新 dwBytesInRes 和 bWidth（256 用 0 表示）
                        new_len = new_sizes[nID]
                        if nID == 7:
                            bWidth, bHeight = 0, 0
                        else:
                            bWidth, bHeight = SIZE_BY_ID[nID][0], SIZE_BY_ID[nID][0]
                        new_entry = struct.pack('<BBBBHHIH', bWidth, bHeight, bColorCount,
                                               bReserved, wPlanes, wBitCount, new_len, nID)
                        content[off:off+14] = new_entry
                        print(f"  GROUP_ICON entry {i} (nID={nID}): bytes {dwBytesInRes} -> {new_len}")
                data_node.content = bytes(content)

    # 3. 写回
    config = lief.PE.Builder.config_t()
    config.resources = True
    builder = lief.PE.Builder(exe, config)
    result = builder.build()
    print("build:", "ok" if isinstance(result, lief.ok_t) else result)
    builder.write(EXE)
    print(f"已写入: {EXE}")

if __name__ == "__main__":
    main()
