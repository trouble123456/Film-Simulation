// settings.ts — the app's own preferences (the macOS `UserDefaults` `ui2.*`).
//
// Per-viewer conveniences live in the webview's localStorage, which Tauri
// keeps in the app's data directory. The store takes its `Storage` as an
// argument (AGENTS.md trap 24): tests inject a throwaway one and never read
// the shared store.

import { createStore, type StoreApi } from 'zustand/vanilla';
import { useStore } from 'zustand';
import type { LanguageSetting } from '../i18n';
import type { SideUnit } from '@shared/params';
import type { PreviewGamut } from '../canvas/colorSpace';
import { RENDER_PREFERENCES_DEFAULT, renderPreferences } from '@shared/renderPreferences';

export type InterfaceScale = 100 | 115 | 130;
export const INTERFACE_SCALES: InterfaceScale[] = [100, 115, 130];
export const PREVIEW_EDGES = [3840, 2560, 1920, 1080] as const;

/**
 * The preview long edge implied by the GPU-memory policy. `auto` picks from
 * the adapter's device-local heap: tight parts (≤4 GiB) drop to 1080, roomy
 * ones (≥12 GiB) step up to 2560, and everything in between stays at the
 * product default 1920. `low`/`high` force the ends of the range explicitly.
 */
export function previewEdgeForMode(mode: Settings['gpuMemoryMode'], deviceMemoryBytes: number): number {
  if (mode === 'low') return 1080;
  if (mode === 'high') return 2560;
  if (deviceMemoryBytes <= 0) return 1920; // shared/unified memory: default
  if (deviceMemoryBytes <= 4 * 1024 ** 3) return 1080;
  if (deviceMemoryBytes >= 12 * 1024 ** 3) return 2560;
  return 1920;
}

/**
 * The export downscale factor for a global preference: 1 (original), 0.5
 * (half) or 0.25 (quarter) of the finished picture's long edge.
 */
export function exportDownscaleFactor(mode: Settings['exportDownscale']): number {
  return mode === 'half' ? 0.5 : mode === 'quarter' ? 0.25 : 1;
}
export const PANEL_WIDTHS = { leftWidth: [232, 254, 380], rightWidth: [268, 288, 364] } as const;
export function boundedPanelWidth(key: keyof typeof PANEL_WIDTHS, width: number): number {
  const [lo, normal, hi] = PANEL_WIDTHS[key];
  return Number.isFinite(width) ? Math.max(lo, Math.min(hi, width)) : normal;
}

export interface Settings {
  language: LanguageSetting;
  interfaceScale: InterfaceScale;
  previewLongEdge: number;
  previewGamut: PreviewGamut;
  sideUnit: SideUnit;
  decoupleEffects: boolean;
  recalculateEffectsAfterCrop: boolean;
  diBlueCompensation: boolean;
  /** GPU memory policy: how much device memory the engine is allowed to use. */
  gpuMemoryMode: 'auto' | 'low' | 'high';
  /** Global export downscale: the finished picture's size vs the original. */
  exportDownscale: 'original' | 'half' | 'quarter';
  parametersTab: 'preDev' | 'postDev';
  leftCollapsed: boolean;
  rightCollapsed: boolean;
  filmstripCollapsed: boolean;
  leftWidth: number;
  rightWidth: number;
  filmEdgeBodySeed: number;
  collapsedSections: Record<string, boolean>;
  lastFolder: string | null;
  settingsPage: 'general' | 'rendering' | 'memory' | 'performance' | 'diagnostics' | 'agents';
}

export const SETTINGS_DEFAULT: Settings = {
  language: 'system',
  interfaceScale: 115,
  // 1920 keeps the preview comfortably under the GPU budget of an 8 GB
  // laptop part (61 MP RAW through the full film pipeline); 3840/2560 stay
  // selectable, and export always runs at full resolution regardless.
  previewLongEdge: 1920,
  // sRGB is the product default: every ordinary display, viewer and lab
  // assumes it. Display P3 stays selectable per user, but is never picked
  // implicitly.
  previewGamut: 'srgb',
  sideUnit: 'mm',
  decoupleEffects: false,
  ...RENDER_PREFERENCES_DEFAULT,
  gpuMemoryMode: 'auto',
  exportDownscale: 'original',
  parametersTab: 'preDev',
  leftCollapsed: false,
  rightCollapsed: false,
  filmstripCollapsed: false,
  leftWidth: 254,
  rightWidth: 288,
  filmEdgeBodySeed: 0,
  collapsedSections: {},
  lastFolder: null,
  settingsPage: 'general',
};

const KEY = 'ui2.settings';

export function loadSettings(storage: Pick<Storage, 'getItem'> | null): Settings {
  try {
    const raw = storage?.getItem(KEY);
    if (!raw) return SETTINGS_DEFAULT;
    const o = JSON.parse(raw) as Partial<Settings>;
    const out = { ...SETTINGS_DEFAULT } as Record<string, unknown>;
    for (const k of Object.keys(SETTINGS_DEFAULT) as (keyof Settings)[]) {
      const v = o[k];
      const d = SETTINGS_DEFAULT[k];
      if (v !== undefined && (typeof v === typeof d || d === null)) out[k] = v;
    }
    const s = out as unknown as Settings;
    if (!INTERFACE_SCALES.includes(s.interfaceScale)) s.interfaceScale = SETTINGS_DEFAULT.interfaceScale;
    if (!(PREVIEW_EDGES as readonly number[]).includes(s.previewLongEdge)) s.previewLongEdge = SETTINGS_DEFAULT.previewLongEdge;
    if (!(['srgb', 'display-p3'] as const).includes(s.previewGamut)) s.previewGamut = SETTINGS_DEFAULT.previewGamut;
    s.leftWidth = boundedPanelWidth('leftWidth', s.leftWidth);
    s.rightWidth = boundedPanelWidth('rightWidth', s.rightWidth);
    if (!Number.isInteger(s.filmEdgeBodySeed) || s.filmEdgeBodySeed < 0 || s.filmEdgeBodySeed > 2147483647) s.filmEdgeBodySeed = 0;
    if (!['general', 'rendering', 'memory', 'performance', 'diagnostics', 'agents'].includes(s.settingsPage)) s.settingsPage = 'general';
    if (!['auto', 'low', 'high'].includes(s.gpuMemoryMode)) s.gpuMemoryMode = 'auto';
    if (!['original', 'half', 'quarter'].includes(s.exportDownscale)) s.exportDownscale = 'original';
    return s;
  } catch {
    return SETTINGS_DEFAULT;
  }
}

export interface SettingsStore extends Settings {
  set<K extends keyof Settings>(key: K, value: Settings[K]): void;
  toggleSection(key: string): void;
}

export function createSettingsStore(storage: Pick<Storage, 'getItem' | 'setItem'> | null): StoreApi<SettingsStore> {
  return createStore<SettingsStore>((set, get) => ({
    ...loadSettings(storage),
    set(key, value) {
      if (key === 'leftWidth' || key === 'rightWidth') value = boundedPanelWidth(key, value as number) as Settings[typeof key];
      set({ [key]: value } as Partial<SettingsStore>);
      persist(get());
    },
    toggleSection(key) {
      const c = { ...get().collapsedSections };
      c[key] = !c[key];
      set({ collapsedSections: c });
      persist(get());
    },
  }));
  function persist(s: SettingsStore) {
    queueMicrotask(() => {
      try {
        const out: Record<string, unknown> = {};
        for (const k of Object.keys(SETTINGS_DEFAULT)) out[k] = (s as unknown as Record<string, unknown>)[k];
        storage?.setItem(KEY, JSON.stringify(out));
      } catch {
        /* private window, blocked storage: the setting lasts the session */
      }
    });
  }
}

function defaultStorage(): Storage | null {
  try {
    return typeof window !== 'undefined' ? window.localStorage : null;
  } catch {
    return null;
  }
}

export const settingsStore = createSettingsStore(defaultStorage());
// The headless CLI has no WebView localStorage. Mirror only the two switches
// that affect pixels, via an atomic native write independent of batch leases.
// Serialize writes so a slow startup save cannot replace a newer selection.
let renderingSave: Promise<void> = Promise.resolve();
export function syncAgentRenderingPreferences(): Promise<void> {
  if (typeof window === 'undefined' || !('__TAURI_INTERNALS__' in window)) return Promise.resolve();
  const preferences = renderPreferences(settingsStore.getState());
  renderingSave = renderingSave.catch(() => undefined).then(async () => {
    const { invoke } = await import('@tauri-apps/api/core');
    await invoke('agent_rendering_set', { preferences });
  });
  return renderingSave;
}
function mirrorRenderingPreferences() {
  void syncAgentRenderingPreferences().catch(async (error: unknown) => {
    console.error('Could not save shared rendering preferences:', error);
    const { message } = await import('@tauri-apps/plugin-dialog');
    await message(`Could not save rendering preferences for command-line tools. Retry changing the setting before using agent export.\n${String(error)}`,
      { title: '胶片模拟', kind: 'error' }).catch((dialogError: unknown) => console.error(dialogError));
  });
}
mirrorRenderingPreferences();
settingsStore.subscribe((next, previous) => {
  if (next.recalculateEffectsAfterCrop !== previous.recalculateEffectsAfterCrop || next.diBlueCompensation !== previous.diBlueCompensation)
    mirrorRenderingPreferences();
});
export function useSettings<T>(sel: (s: SettingsStore) => T): T {
  return useStore(settingsStore, sel);
}
